from csv import DictReader, DictWriter

locs = {'BEAUFORT':'111',
	'BERKELEY':'112',
	'CHARLESTON':'113',
	'COLLETON':'114',
	'DORCHESTER':'115'}
street_vals = set(['St','Dr','Gtwy','Hwy','Rd','Cir','Blvd','Ave','Pkwy','Ln','Highway','Circle','Street','Avenue','Road','Lane','Boulevard','Drive','Way','Ct','Streets','Parkway'])
count = 0

def parse_add(add_list):
	for i in range(len(add_list)):
		if add_list[i] in street_vals:
			if add_list[i] == "Highway" and add_list[i+1].isdigit():
				return ' '.join(add_list[0:i+2]), ' '.join(add_list[i+2:])
			else:
				return ' '.join(add_list[0:i+1]), ' '.join(add_list[i+1:])

with open('PollingLocation.csv','r') as r, open('precinct.txt','w') as p, open('precinct_polling_location.txt','w') as pp, open('polling_location.txt','w') as po:
	reader = DictReader(r)
	prec = DictWriter(p,fieldnames=['name','number','locality_id','id'])
	precpoll = DictWriter(pp,fieldnames=['precinct_id','polling_location_id'])
	poll = DictWriter(po,fieldnames=['address_location_name','address_line1','address_city','address_state','address_zip','id'])
	prec.writeheader()
	precpoll.writeheader()
	poll.writeheader()
	for row in reader:
		count += 1
		prec.writerow({'name':row['PrecinctName'],
				'number':row['PrecinctCode'],
				'id':'66' + str(count),
				'locality_id':str(locs[row['CountyName']])})
		precpoll.writerow({'precinct_id':'66' + str(count),
					'polling_location_id':'77' + str(count)})
		zipcode = row['PollingLocationAddress'][-5:]
		line1, city = parse_add(row['PollingLocationAddress'][:-9].split())
		poll.writerow({'id':'77' + str(count),
				'address_location_name':row['PollingLocationName'],
				'address_line1':line1,
				'address_city':city,
				'address_zip':zipcode,
				'address_state':'SC'})
