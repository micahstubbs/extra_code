from csv import DictReader, DictWriter

f_list = ['07BeaufortStreetSeg.csv', '08BerkeleyStreetSeg.csv', '10CharlestonStreetSeg.csv', '15ColletonStreetSeg.csv', '18DorchesterStreetSeg.csv']
precs = {}
p_str = 'Precinct: {number} {name}'
count = 0

with open('sc_legit/precinct.txt','r') as p:
	reader = DictReader(p)
	for row in reader:
		precs[p_str.format(**row)] = row['id']
with open('streetsegment.txt','w') as w:
	writer = DictWriter(w,fieldnames=['start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_street_name','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id','id'])
	writer.writeheader()
	for f in f_list:
		with open(f,'r') as r:
			reader = DictReader(r)
			for row in reader:
				count += 1
				if row['AddressRange'].find('-') >= 0:
					try:
						start = str(int(row['AddressRange'].split('-')[0]))
						end = str(int(row['AddressRange'].split('-')[1]))
					except:
						start = ''
						end = ''
				else:
					start = ''
					end = ''
				if row['UnitRange'].find('-') >= 0:
					apt_start = row['UnitRange'].split('-')[0]
					apt_end = row['UnitRange'].split('-')[1]
				else:
					apt_start = ''
					apt_end = ''
				writer.writerow({'start_house_number':start,
						'end_house_number':end,
						'odd_even_both':row['Area'].upper(),
						'start_apartment_number':apt_start,
						'end_apartment_number':apt_end,
						'non_house_address_street_name':row['StreetName'],
						'non_house_address_city':'',
						'non_house_address_state':'SC',
						'non_house_address_zip':row['ZipCode'],
						'precinct_id':precs[row['PrecinctCode']],
						'id':'88'+str(count)})

