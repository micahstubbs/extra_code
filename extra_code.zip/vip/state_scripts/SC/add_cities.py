from csv import DictReader,DictWriter

zipvals = {}

with open('citystuff.txt','r') as r:
	reader = DictReader(r)
	for row in reader:
		if len(row['ZipCodes']) > 0:
			city = row['DistrictName'].strip()
			zips = row['ZipCodes'].split(',')
			for z in zips:
				if z in zipvals and zipvals[z] != city:
					print z
				zipvals[z] = city

