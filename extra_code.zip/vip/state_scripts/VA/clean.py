from csv import DictReader, DictWriter

contests = set()
ballots = set()
with open('contest.txt') as r, open('clean_contest.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		if row['id'] in contests:
			continue
		contests.add(row['id'])
		ballots.add(row['ballot_id'])
		row['type'] = 'Primary'
		row['election_id'] = '13511'
		writer.writerow(row)
with open('ballot.txt') as r, open('clean_ballot.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		if row['id'] in ballots:
			for k,v in row.iteritems():
				if v == 'NULL':
					row[k] = ''
			writer.writerow(row)
with open('ballot_candidate.txt') as r, open('clean_ballot_candidate.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		if row['ballot_id'] in ballots:
			for k,v in row.iteritems():
				if v == 'NULL':
					row[k] = ''
			writer.writerow(row)
with open('candidate.txt') as r, open('clean_candidate.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		for k,v in row.iteritems():
			if v == 'NULL':
				row[k] = ''
		writer.writerow(row)
