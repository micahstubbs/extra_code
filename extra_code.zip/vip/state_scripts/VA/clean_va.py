from csv import DictReader, DictWriter

files = ['ballot_candidate.txt','polling_location.txt','ballot.txt','precinct_polling_location.txt','candidate.txt','precinct_split_electoral_district.txt','precinct_split.txt','contest.txt','precinct.txt','election_administration.txt','referendum.txt','election_official.txt','source.txt','election.txt','state.txt','electoral_district.txt','street_segment.txt','locality.txt']

prec_polls = set()

for f in files:
	with open(f,'r') as r, open('clean/'+f,'w') as w:
		reader = DictReader(r)
		writer = DictWriter(w, fieldnames=reader.fieldnames)
		writer.writeheader()
		for row in reader:
			for k,v in row.iteritems():
				if k == 'election_id':
					row[k] = '13511'
				if v == 'NULL':
					row[k] = ''
				elif v.startswith(','):
					row[k] = row[k][1:]
			if f == 'precinct_polling_location.txt' and (row['precinct_id'],row['polling_location_id']) in prec_polls:
				continue
			elif f == 'precinct_polling_location.txt':
				prec_polls.add((row['precinct_id'],row['polling_location_id']))
			elif f == 'contest.txt':
				row['type'] = 'Primary'
			writer.writerow(row)
		
