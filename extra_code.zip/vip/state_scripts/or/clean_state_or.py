from csv import DictReader,DictWriter
state_id='41'
locs = {}
loc_count = 0
with open('dropsites.csv','r') as r, open('locality.txt','w') as lw:
	reader = DictReader(r)
	locwriter = DictWriter(lw,fieldnames=['name','state_id','type','election_administration_id','id'])
	locwriter.writeheader()
	for row in reader:
		if row['County'] not in locs:
			loc_count += 1
			locs[row['County']] = '11'+str(loc_count)
			locwriter.writerow({'id':locs[row['County']],
						'name':row['County'],
						'type':'County',
						'state_id':'41'})
with open('dropsites.csv','r') as r, open('early_vote_site.txt','w') as ew, open('state_early_vote_site.txt','w') as lew:
	reader = DictReader(r)
	earlywriter = DictWriter(ew,fieldnames=['address_location_name','address_line1','address_city','address_state','address_zip','directions','voter_services','start_date','end_date','days_times_open','id'])
	locearlywriter = DictWriter(lew,fieldnames=['state_id','early_vote_site_id'])
	earlywriter.writeheader()
	locearlywriter.writeheader()
	for row in reader:
		#for k,v in locs.iteritems():
		locearlywriter.writerow({'state_id':'41',
						'early_vote_site_id':'99'+row['ID']})
		earlywriter.writerow({'id':'99'+row['ID'],
					'address_location_name':row['Name'],
					'address_line1':row['Address'],
					'address_city':row['City'],
					'address_state':'OR',
					'address_zip':row['ZIP'],
					'directions':row['Location'],
					'start_date':'2012-10-19',
					'end_date':'2012-11-06',
					'days_times_open':row['Hours']})

with open('OR_vf_ex_precincts.txt','r') as r, open('precinct.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['locality_id','name','number','ward','mail_only','id'])
	writer.writeheader()
	for row in reader:
		writer.writerow({'id':row['vf_precinct_id'],
				'locality_id':locs[row['vf_precinct_county'].title()],
				'name':row['vf_precinct_name'],
				'number':row['vf_precinct_code'],
				'ward':row['vf_precinct_ward'],
				'mail_only':'YES'})
	
with open('OR_vf_deduped.txt','r') as r, open('street_segment.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_street_direction','non_house_address_street_name','non_house_address_street_suffix','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id','id'])
	writer.writeheader()
	for row in reader:
		writer.writerow({'id':row['vf_id'],
				'precinct_id':row['vf_precinct_id'],
				'start_house_number':row['house_number'],
				'end_house_number':row['house_number'],
				'odd_even_both':'both',
				'start_apartment_number':row['apartment_number'],
				'end_apartment_number':row['apartment_number'],
				'non_house_address_street_direction':row['street_direction'],
				'non_house_address_street_name':row['street_name'],
				'non_house_address_street_suffix':row['street_suffix'],
				'non_house_address_city':row['city'],
				'non_house_address_state':row['state'],
				'non_house_address_zip':row['zip']})
