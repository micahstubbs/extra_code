import MySQLdb as mdb
import csv

connection = mdb.connect('localhost', 'iowa', 'password', 'iowa')

cursor = connection.cursor()

reader = csv.DictReader(open('raw_data/Locality.txt'),delimiter='|')

for row in reader:
	cursor.execute('INSERT INTO Locality (id, name) VALUES (' + row['LOCALITY_ID'] + ', "' + row['NAME'] + ' ' + row['TYPE'] + '")')

reader = csv.DictReader(open('raw_data/Precincts.txt'),delimiter='|')

for row in reader:
	cursor.execute('INSERT INTO Precincts (id, name, locality_id, polling_location_id, district_code) VALUES (' + row['ID'] + ', "' + row['NAME'] + '", ' + row['LOCALITY_ID'] + ', ' + row['POLLING_LOCATION_ID'] + ', "' + row['DISTRICT_CODE'] + '")')

reader = csv.DictReader(open('raw_data/Precinct_Splits.txt'),delimiter='|')

for row in reader:
	cursor.execute('INSERT INTO Precinct_Splits(id, name, precinct_id) VALUES (' + row['ID'] + ', "' + row['name'] + '", ' + row['precinct_id'] + ')')

connection.commit()
