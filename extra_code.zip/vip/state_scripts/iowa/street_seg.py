import MySQLdb as mdb
import csv

connection = mdb.connect('localhost', 'iowa', 'password', 'iowa')

cursor = connection.cursor()

reader = csv.DictReader(open('raw_data/Street_Segments.txt'),delimiter='|')

for row in reader:
	query = 'INSERT INTO Street_Segments(id, start_house_number, end_house_number, odd_even_both, street_direction, street_name, street_suffix, address_direction, state, city, zip, precinct_id) VALUES (' + row['STREET_SEGMENT_ID'] + ', ' + row['START_HOUSE_NUMBER'] + ', ' + row['END_HOUSE_NUMBER'] + ', ' + row['ODD_EVEN_BOTH'] + ', ' + row["STREET_DIRECTION"] + ', ' + row["STREET_NAME"] + ', ' + row["STREET_SUFFIX"] + ', ' + row["ADDRESS_DIRECTION"] + ', ' + row["STATE"] + ', ' + row["City"] + ', ' + row["Zip"] + ', ' + row["PRECINCT_ID"] + ')'
	print query
	cursor.execute('INSERT INTO Street_Segments(id, start_house_number, end_house_number, odd_even_both, street_direction, street_name, street_suffix, address_direction, state, city, zip, precinct_id) VALUES (' + row['STREET_SEGMENT_ID'] + ', ' + row['START_HOUSE_NUMBER'] + ', ' + row['END_HOUSE_NUMBER'] + ', "' + row['ODD_EVEN_BOTH'] + '", "' + row["STREET_DIRECTION"] + '", "' + row["STREET_NAME"] + '", "' + row["STREET_SUFFIX"] + '", "' + row["ADDRESS_DIRECTION"] + '", "' + row["STATE"] + '", "' + row["City"] + '", ' + row["Zip"] + ', ' + row["PRECINCT_ID"] + ')')

connection.commit()
