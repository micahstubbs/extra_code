from BeautifulSoup import BeautifulSoup
import urllib2
import csv

soup = BeautifulSoup(open("data1.xml"))

polling_data = []

#TODO: Convert to a db, then ping google api with 'city, state, zip' to get county information, if zip does not exist, then use whole address
#then hash the address to the county name for each address, and if it already exists in the dictionary, return that instead of hitting the google api
#then do a search on the locality table to get the locality_id for the county to store in the db along with the other polling location information
#finally, do a precinct_name check vs district_name and locality_id in the precinct table to find all matches and non-matches, find out how many hand
#matches are required
#could eliminate the first find, but leaving this in just in case thay alter the page later
location_names = soup.find('div', attrs={'class':'contentleft'}).findAll('div', attrs={'class':'locationname'})
precincts = soup.find('div', attrs={'class':'contentleft'}).findAll('div', attrs={'class':'precinct'})
addresses = soup.find('div', attrs={'class':'contentleft'}).findAll('div', attrs={'class':'address'})

print len(addresses)
print len(location_names)
print len(precincts)

for i in range(len(location_names)):
	polling_data.append({})
	polling_data[i]["location_name"] = location_names[i].text
	polling_data[i]["precinct_name"] = str(precincts[i].text.replace("Precinct: ", ""))
	address = addresses[i].renderContents().split("<br />\r\n")
	polling_data[i]["line_1"] = address[0]
	city_state = address[1].split(",")
	polling_data[i]["city"] = city_state[0] 
	polling_data[i]["state"] = "IA"
	state_zip = city_state[1].strip().split(" ")
	if len(state_zip) > 1:
		polling_data[i]["zip"] = state_zip[1]
	else:
		polling_data[i]["zip"] = ""

print polling_data

dw = csv.DictWriter(open('raw_data/gop_caucus_locations.txt', "w"), fieldnames=["location_name","precinct_name","line_1","city","state","zip"])

for row in polling_data:
	dw.writerow(row)
