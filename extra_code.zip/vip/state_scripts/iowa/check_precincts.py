import MySQLdb as mdb
import csv

connection = mdb.connect('localhost', 'iowa', 'password', 'iowa', cursorclass=mdb.cursors.DictCursor)

cursor = connection.cursor()

reader = csv.DictReader(open('raw_data/gop_caucus_locations.txt'),delimiter=',')

match_writer = csv.DictWriter(open('raw_data/caucus_matches.txt', 'w'), fieldnames=["location_name","precinct_name","address","precinct_id"])
mismatch_writer = csv.DictWriter(open('raw_data/caucus_mismatches.txt', 'w'), fieldnames=["location_name","precinct_name","address"])

for row in reader:
	cursor.execute("SELECT * FROM Precincts where district_code = '" + row["precinct_name"] + "'")
	data = cursor.fetchall()
	if len(data) == 1:
		row["precinct_id"] = data[0]["precinct_id"]
		print row
		match_writer.writerow(row)
	else:
		mismatch_writer.writerow(row)
