import csv
import MySQLdb
import MySQLdb.cursors
import codecs

def is_str_int(s):
	try:
		int(s)
		return True
	except ValueError:
		return False

data = csv.DictReader(codecs.open('raw_data/gop_caucus_12_29.txt', 'r', "utf-8-sig"))

errs = open('raw_data/match_errs.txt', 'w')

matched = open('raw_data/matched.txt', 'w')

connection = MySQLdb.connect('localhost', 'iowa', 'password', 'iowa', cursorclass=MySQLdb.cursors.DictCursor)
cursor = connection.cursor()

matches = 0
first_non_matches = 0
complete_non_matches = 0

for row in data:
	cursor.execute('SELECT * from Precincts where name like "' + row["Precinct Name"].strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
	results = cursor.fetchall()
	if len(results) == 1:
		row["id"] = str(results[0]["polling_location_id"])
	else:
		first_non_matches += 1
		cursor.execute('SELECT * from Precincts where district_code like "' + row["Code"].strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
		results = cursor.fetchall()
		if len(results) == 1:
			row["id"] = str(results[0]["polling_location_id"])
		else:
			cursor.execute('SELECT * from Precincts where name like "' + row["Precinct Name"].replace('Precinct', '').strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
			results = cursor.fetchall()
			if len(results) == 1:
				row["id"] = str(results[0]["polling_location_id"])
			else:
				name_info = row["Precinct Name"].split(" ")
				name_plus_zero = ""
				name_plus_plus_zero = ""
				for n in name_info:
					if is_str_int(n):
						name_plus_zero += "0"
						name_plus_plus_zero += "00"
					name_plus_zero += n + " "
					name_plus_plus_zero += n + " "
				cursor.execute('SELECT * from Precincts where name like "' + name_plus_zero.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
				results = cursor.fetchall()
				if len(results) == 1:
					row["id"] = str(results[0]["polling_location_id"])
				else:
					cursor.execute('SELECT * from Precincts where name like "' + name_plus_plus_zero.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
					results = cursor.fetchall()
					if len(results) == 1:
						row["id"] = str(results[0]["polling_location_id"])
					else:
						name_cast_int = ""
						for n in name_info:
							if is_str_int(n):
								name_cast_int += str(int(n)) + " "
							else:
								name_cast_int += n + " "
						cursor.execute('SELECT * from Precincts where name like "' + name_cast_int.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
						results = cursor.fetchall()
						if len(results) == 1:
							row["id"] = str(results[0]["polling_location_id"])
						else:
							code_info = row["Code"].split(" ")
							code_plus_zero = ""
							for n in code_info:
								if is_str_int(n):
									code_plus_zero += "0"
								code_plus_zero += n + " "
							cursor.execute('SELECT * from Precincts where district_code like "' + code_plus_zero.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
							results = cursor.fetchall()
							if len(results) == 1:
								row["id"] = str(results[0]["polling_location_id"])
							else:
								code_plus_zero = ""
								first_int = True
								for c in row["Code"]:
									if c.isdigit() and first_int:
										code_plus_zero += "0"
										first_int = False
									code_plus_zero += c
								cursor.execute('SELECT * from Precincts where district_code like "' + code_plus_zero.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
								results = cursor.fetchall()
								if len(results) == 1:
									row["id"] = str(results[0]["polling_location_id"])
								else:
									code_name_split = row["Precinct Name"].split(" ")
									if len(code_name_split) == 2:
										cursor.execute('SELECT * from Precincts where district_code like "0' + code_name_split[1] + '" and name like "' + code_name_split[0] + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
										results = cursor.fetchall()
									if len(results) == 1:
										row["id"] = str(results[0]["polling_location_id"])
									else:
										if "-" in row["Precinct Name"] and len(code_name_split) == 2:
											code = row["Code"] + " " + code_name_split[1]
											cursor.execute('SELECT * from Precincts where district_code like "' + code + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
											results = cursor.fetchall()
										if len(results) == 1:
											row["id"] = str(results[0]["polling_location_id"])
	if len(results) == 1:
		matched.write(results[0]["name"] + "," + row["Precinct Name"] + "," + results[0]["district_code"] + "," + row["Code"] + "\n")
	else:
		errs.write(row["Precinct Name"] + "," + row["Code"])	

matched.close()
errs.close()

