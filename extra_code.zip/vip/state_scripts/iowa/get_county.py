import urllib
import urllib2
import json
import csv
import MySQLdb
import MySQLdb.cursors
from time import sleep

connection = MySQLdb.connect('localhost', 'iowa', 'password', 'iowa', cursorclass=MySQLdb.cursors.DictCursor)

cursor = connection.cursor()

city_info = {}

data = csv.DictReader(open('raw_data/gop_caucus_locations.txt', 'r'))

error_data = csv.DictWriter(open('raw_data/caucus_errors.txt', 'w'), fieldnames=["location_name","district_code","line_1","city","state","zip"])

locality_ids = open('raw_data/locality_info.txt', 'w')

counter =  0

for row in data:
	if len(row["zip"]) > 0:
		city_zip = str(row["city"]) + ", " + str(row["state"]) + " " + str(row["zip"])
	else:
		if len(row["city"]) <= 0:
			error_data.writerow(row)
			continue
		else:
			city_zip = str(row["line_1"]) + ", " + str(row["city"]) + ", " + str(row["state"]) 
	if not city_zip in city_info:
		request = {"address":city_zip, "sensor":"false"}
		edata = urllib.urlencode(request)
		data = json.load(urllib2.urlopen("http://maps.googleapis.com/maps/api/geocode/json?" + edata))
		print data
		sleep(1)

		for i in data["results"][0]["address_components"]:
			if "administrative_area_level_2" in i["types"]:
				print i["long_name"]
				cursor.execute('select * from Locality where name like "' + i["long_name"] + ' County"')
		locality = cursor.fetchone()
		if locality is None <= 0 or not "id" in locality:
			error_data.writerow(row)
			continue	
		city_info[city_zip] = locality["id"]
		locality_ids.write('"' + str(city_zip) + '",' + str(locality["id"]) + '\n')
	row["locality_id"] = city_info[city_zip]
	if len(row["zip"]) > 0:
		query = 'INSERT INTO caucus_locations(id, location_name, line_1, city, state, zip, locality_id, district_code) VALUES (' + str(counter+50000) + ', "' + row["location_name"] + '\", \"' + row["line_1"] + '\", \"' + row["city"] + '\", \"' + row["state"] + '\", ' + str(row["zip"]) + ", " + str(row["locality_id"]) + ", '" + row["district_code"] + "')"
	else:
		query = 'INSERT INTO caucus_locations(id, location_name, line_1, city, state, locality_id, district_code) VALUES (' + str(counter+50000) + ', "' + row["location_name"] + '\", \"' + row["line_1"] + '\", \"' + row["city"] + '\", \"' + row["state"] + '\", ' + str(row["locality_id"]) + ", '" + row["district_code"] + "')"
	print query
	cursor.execute(query)
	counter += 1

connection.commit()
