import csv
import MySQLdb
import MySQLdb.cursors
from lxml import etree
import codecs

connection = MySQLdb.connect('localhost', 'iowa', 'password', 'iowa', cursorclass=MySQLdb.cursors.DictCursor)
cursor = connection.cursor()

schemaUrl = "http://election-info-standard.googlecode.com/files/vip_spec_v3.0xsd"

print "creating vipObject..."
	
NS = 'http://www.w3.org/2001/XMLSchema-instance'
location_attribute = '{%s}noNamespaceSchemaLocation' % NS
	
# -*- coding: utf-8 -*-

vipObj = etree.Element('vip_object', attrib={location_attribute: schemaUrl})
vipObj.set("schemaVersion","3.0")
	
print "finished creating vipObject"

cursor.execute("SELECT * FROM Locality")
results = cursor.fetchall()

for r in results:
	element = etree.SubElement(vipObj, "locality")
	element.set("id", str(r["id"]))
	subelem1 = etree.SubElement(element, "name")
	subelem1.text = r["name"]
	subelem2 = etree.SubElement(element, "state_id")
	subelem2.text = "19"
	subelem3 = etree.SubElement(element, "type")
	subelem3.text = "County"

cursor.execute("SELECT * FROM Precincts where name not like '%Z Delete%'")
results = cursor.fetchall()

for r in results:
	element = etree.SubElement(vipObj, "precinct")
	element.set("id", str(r["id"]))
	subelem1 = etree.SubElement(element, "name")
	subelem1.text = r["name"]
	subelem2 = etree.SubElement(element, "number")
	subelem2.text = r["district_code"]
	subelem3 = etree.SubElement(element, "locality_id")
	subelem3.text = str(r["locality_id"])
	subelem3 = etree.SubElement(element, "polling_location_id")
	subelem3.text = str(r["polling_location_id"])

cursor.execute("SELECT * FROM Precinct_Splits")
results = cursor.fetchall()

for r in results:
	element = etree.SubElement(vipObj, "precinct_split")
	element.set("id", str(r["id"]))
	subelem1 = etree.SubElement(element, "name")
	subelem1.text = r["name"]
	subelem2 = etree.SubElement(element, "precinct_id")
	subelem2.text = str(r["precinct_id"])

def is_str_int(s):
	try:
		int(s)
		return True
	except ValueError:
		return False

data = csv.DictReader(codecs.open('raw_data/gop_caucus_12_29.txt', 'r', "utf-8-sig"))

errs = open('raw_data/errors.txt', 'w')

connection = MySQLdb.connect('localhost', 'iowa', 'password', 'iowa', cursorclass=MySQLdb.cursors.DictCursor)
cursor = connection.cursor()

matches = 0
first_non_matches = 0
complete_non_matches = 0

for row in data:
	#print row
	cursor.execute('SELECT * from Precincts where name like "' + row["Precinct Name"].strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
	results = cursor.fetchall()
	if len(results) == 1:
		row["id"] = str(results[0]["polling_location_id"])
	else:
		first_non_matches += 1
		cursor.execute('SELECT * from Precincts where district_code like "' + row["Code"].strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
		results = cursor.fetchall()
		if len(results) == 1:
			row["id"] = str(results[0]["polling_location_id"])
		else:
			cursor.execute('SELECT * from Precincts where name like "' + row["Precinct Name"].replace('Precinct', '').strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
			results = cursor.fetchall()
			if len(results) == 1:
				row["id"] = str(results[0]["polling_location_id"])
			else:
				name_info = row["Precinct Name"].split(" ")
				name_plus_zero = ""
				name_plus_plus_zero = ""
				for n in name_info:
					if is_str_int(n):
						name_plus_zero += "0"
						name_plus_plus_zero += "00"
					name_plus_zero += n + " "
					name_plus_plus_zero += n + " "
				cursor.execute('SELECT * from Precincts where name like "' + name_plus_zero.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
				results = cursor.fetchall()
				if len(results) == 1:
					row["id"] = str(results[0]["polling_location_id"])
				else:
					cursor.execute('SELECT * from Precincts where name like "' + name_plus_plus_zero.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
					results = cursor.fetchall()
					if len(results) == 1:
						row["id"] = str(results[0]["polling_location_id"])
					else:
						name_cast_int = ""
						for n in name_info:
							if is_str_int(n):
								name_cast_int += str(int(n)) + " "
							else:
								name_cast_int += n + " "
						cursor.execute('SELECT * from Precincts where name like "' + name_cast_int.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
						results = cursor.fetchall()
						if len(results) == 1:
							row["id"] = str(results[0]["polling_location_id"])
						else:
							code_info = row["Code"].split(" ")
							code_plus_zero = ""
							for n in code_info:
								if is_str_int(n):
									code_plus_zero += "0"
								code_plus_zero += n + " "
							cursor.execute('SELECT * from Precincts where district_code like "' + code_plus_zero.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
							results = cursor.fetchall()
							if len(results) == 1:
								row["id"] = str(results[0]["polling_location_id"])
							else:
								code_plus_zero = ""
								first_int = True
								for c in row["Code"]:
									if c.isdigit() and first_int:
										code_plus_zero += "0"
										first_int = False
									code_plus_zero += c
								cursor.execute('SELECT * from Precincts where district_code like "' + code_plus_zero.strip() + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
								results = cursor.fetchall()
								if len(results) == 1:
									row["id"] = str(results[0]["polling_location_id"])
								else:
									code_name_split = row["Precinct Name"].split(" ")
									if len(code_name_split) == 2:
										cursor.execute('SELECT * from Precincts where district_code like "0' + code_name_split[1] + '" and name like "' + code_name_split[0] + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
										results = cursor.fetchall()
									if len(results) == 1:
										row["id"] = str(results[0]["polling_location_id"])
									else:
										if "-" in row["Precinct Name"] and len(code_name_split) == 2:
											code = row["Code"] + " " + code_name_split[1]
											cursor.execute('SELECT * from Precincts where district_code like "' + code + '" AND locality_id = ' + str(int(row["County Number"]) + 333300))
											results = cursor.fetchall()
										if len(results) == 1:
											row["id"] = str(results[0]["polling_location_id"])
										else:
			#TODO: Issues with Eden Twp (23) and Dennison 2 (24) - no easy solution, only special cases, also Washington Ward 1-4 = 10 unsolvable precincts
											complete_non_matches += 1
											print "Counter Number: " + str(row["County Number"]) + ", Precinct Name: " + str(row["Precinct Name"]) + ", Code: " + str(row["Code"]) 
	if len(results) == 1:
		element = etree.SubElement(vipObj, "polling_location")
		element.set("id", str(row["id"]))
		address = etree.SubElement(element, "address")
		address_elem1 = etree.SubElement(address, "location_name")
		address_elem1.text = str(row["Caucus Site"])
		address_elem2 = etree.SubElement(address, "line1")
		address_elem2.text = str(row["Caucus Address"])
		address_elem3 = etree.SubElement(address, "city")
		address_elem3.text = str(row["Caucus City"])
		address_elem4 = etree.SubElement(address, "state")
		address_elem4.text = "IA"
		address_elem5 = etree.SubElement(address, "zip")
		address_elem5.text = str(row["Caucus Zip"])

cursor.execute("SELECT * FROM Street_Segments")
results = cursor.fetchall()

for r in results:
	element = etree.SubElement(vipObj, "street_segment")
	element.set("id", str(r["id"]))
	subelem1 = etree.SubElement(element, "start_house_number")
	subelem1.text = str(r["start_house_number"])
	subelem2 = etree.SubElement(element, "end_house_number")
	subelem2.text = str(r["end_house_number"])
	subelem3 = etree.SubElement(element, "odd_even_both")
	subelem3.text = r["odd_even_both"]
	non_house_address = etree.SubElement(element, "non_house_address")
	non_house_address_elem1 = etree.SubElement(non_house_address, "street_direction")
	non_house_address_elem1.text = r["street_direction"]
	non_house_address_elem2 = etree.SubElement(non_house_address, "street_name")
	non_house_address_elem2.text = r["street_name"]
	non_house_address_elem3 = etree.SubElement(non_house_address, "street_suffix")
	non_house_address_elem3.text = r["street_suffix"]
	non_house_address_elem4 = etree.SubElement(non_house_address, "address_direction")
	non_house_address_elem4.text = r["address_direction"]
	non_house_address_elem5 = etree.SubElement(non_house_address, "state")
	non_house_address_elem5.text = r["state"]
	non_house_address_elem6 = etree.SubElement(non_house_address, "city")
	non_house_address_elem6.text = r["city"]
	non_house_address_elem7 = etree.SubElement(non_house_address, "zip")
	non_house_address_elem7.text = str(r["zip"])
	subelem5 = etree.SubElement(element, "precinct_id")
	subelem5.text = str(r["precinct_id"])



print "matches: " + str(matches)
print "first_non_matches: " + str(first_non_matches)
print "complete_non_matches: " + str(complete_non_matches)

f = open("IA_feed.xml", "w")
f.write(etree.tostring(vipObj, pretty_print=True, xml_declaration=True, encoding="utf-8"))
f.close()
	
	
