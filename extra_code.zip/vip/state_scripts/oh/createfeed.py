import csv
from lxml import etree
from datetime import datetime

OUTPUT = "feed_data/OH-data.xml"
STATE_ID = "39"

types = ["header", "locality", "admin", "official"]
headerdata = {"state_id":STATE_ID, "state_name":"OHIO", "organization_url":"http://www.sos.state.oh.us/SOS/voter.aspx", "script_start":datetime.isoformat(datetime.today())[:-7], "is_statewide":"Yes", "polling_hours":"6:30 AM - 7:30 PM", "registration_deadline":"2011-10-11", "election_id":"2011", "election_date":"2011-11-08", "election_type":"General"}
headerinfo = ['<?xml version="1.0" standalone="yes"?>', '<vip_object xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://election-info-standard.googlecode.com/files/vip_spec_v3.0.xsd" schemaVersion="3.0">']

w = open(OUTPUT, "a")

for i in range(len(types)):
	
	if types[i] == "header":
		for j in range(len(headerinfo)):
			w.write(headerinfo[j])
	
	
