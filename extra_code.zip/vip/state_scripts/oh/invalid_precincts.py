import sqlite3, csv

voter_file_precincts = []

connection = sqlite3.connect('feed_data/test.db')

c = connection.cursor()

c.execute('SELECT * FROM precincts')

for row in c:
	precinct = {}
	precinct["code"] = row[0]
	precinct["name"] = row[1]
	voter_file_precincts.append(precinct)

data = csv.DictReader(open("feed_data/ohio_polling_locations.csv","r"))
polling_precincts = []

for row in data:
	precinct = {}
	precinct["code"] = row["STATE_PRECINCT_CODE"]
	precinct["name"] = row["NAME"]
	polling_precincts.append(precinct)
code_error_list = []
name_error_list = []

print len(voter_file_precincts)
print len(polling_precincts)

for vfp in voter_file_precincts:
	match = False
	for pp in polling_precincts:
		if vfp["code"].upper() == pp["code"].upper():
			match = True
			break
	if match == False:
		code_error_list.append(vfp["code"])
		name_error_list.append(vfp["name"])

print code_error_list
print name_error_list

code_error_list = []

for pp in polling_precincts:
	match = False
	for vfp in voter_file_precincts:
		if vfp["code"].upper() == pp["code"].upper():
			match = True
			break
	if match == False:
		code_error_list.append(pp["code"])
print code_error_list
