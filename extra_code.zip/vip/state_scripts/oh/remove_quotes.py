f = open('feed_data/SWVF_45_88cleandata.err', 'r')
w = open('clean_errors.txt', 'w')
for line in f:
	w.write(line.replace('"', ''))

f = open('feed_data/SWVF_1_44cleandata.err', 'r')
for line in f:
	w.write(line.replace('"', ''))
w.close()
