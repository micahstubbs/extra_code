import csv

data = csv.reader(open("feed_data/ohio_boe.csv", "r"))

w = csv.DictWriter(open("feed_data/OH_BOE_clean.csv", "w"), fieldnames="id type name state_id ea_id eo_id physical_location_name physical_line1 physical_line2 mailing_line1 mailing_line2 city state zip hours phone fax email elections_url".split())

linecounter = 0

state_id = "39"
ea_id = ""
for char in "EA":
	ea_id += str(ord(char))
eo_id = ""
for char in "EO":
	eo_id += str(ord(char))

w.writeheader()

for line in data:
	boedata = {}

	prefix = str('%02d' % (linecounter+1)) 
	boedata["name"] = line[6]
	boedata["id"] = state_id + prefix 
	boedata["type"] = "county"
	boedata["state_id"] = state_id
	boedata["ea_id"] = prefix + ea_id
	boedata["eo_id"] = prefix + eo_id	

	line = data.next()
	boedata["physical_location_name"] = line[6]

	line = data.next()
	address = line[6].split(",")
	for i in range(len(address)):
		boedata["physical_line%d" % (i+1)] = address[i]
	if len(address) < 2:
		boedata["physical_line2"] = ""
	
	line = data.next()
	if len(line[6]) > 0:
		boedata["mailing_line1"] = line[6]
		boedata["mailing_line2"] = ""
	else:
		boedata["mailing_line1"] = boedata["physical_line1"]
		boedata["mailing_line2"] = boedata["physical_line2"]

	line = data.next()
	location = line[6].split(",")
	boedata["city"] = location[0]
	boedata["state"] = "OH"
	boedata["zip"] = location[1].strip().lstrip("OH").lstrip()

	line = data.next()
	boedata["hours"] = line[6].replace("Office Hours:", "").replace("&", "and").strip()

	line = data.next()
	numbers = line[6].split("/")
	boedata["phone"] = numbers[0].replace("Telephone:", "").strip()
	if len(numbers) > 1:
		boedata["fax"] = numbers[1].replace("Fax:", "").strip()

	line = data.next()
	webstuff = line[6].split("/")
	boedata["email"] = webstuff[0].lower().replace("e-mail:", "").strip()
	if len(webstuff) > 1:
		new_web = ""
		for i in range(len(webstuff)-1):
			new_web += webstuff[i+1] +"/"
		boedata["elections_url"] = new_web.replace("Website:", "").replace("//","/").strip()
	else:
		boedata["elections_url"] = ""

	w.writerow(boedata)
	
	try:
		line = data.next()
	except:
		break
	linecounter += 1

