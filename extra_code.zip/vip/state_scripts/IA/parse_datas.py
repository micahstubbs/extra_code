from csv import DictReader,DictWriter
from hashlib import md5

def hash_list(row,fields):
	m = md5()
	for f in fields:
		m.update(row[f])
	return m.hexdigest()

locs = {}

with open('locality.txt','r') as r:
	reader = DictReader(r)
	for row in reader:
		locs[row['name'].upper().replace("'",'')] = row['id'][2:]
precincts = {}
prec_count = 0
with open('prec_poll_iowa.csv','r') as r, open('precinct.txt','w') as pw, open('precinct_polling_location.txt','w') as ppw, open('polling_location.txt','w') as pollw:
	reader = DictReader(r)
	precwriter = DictWriter(pw,fieldnames=['id','name','number','locality_id'])
	precpollwriter = DictWriter(ppw,fieldnames=['precinct_id','polling_location_id'])
	pollwriter = DictWriter(pollw,fieldnames=['id','address_location_name','address_line1','address_city','address_state','address_zip'])
	precwriter.writeheader()
	precpollwriter.writeheader()
	pollwriter.writeheader()
	for row in reader:
		prec_count += 1
		precinct_id = '22' + str(prec_count)
		polling_location_id = '33' + str(prec_count)
		precincts[locs[row['County'].upper().replace("'",'')]+'*'+row['Precinct Code']] = precinct_id
		precpollwriter.writerow({'precinct_id':precinct_id,
						'polling_location_id':polling_location_id})
		precwriter.writerow({'id':precinct_id,
					'locality_id':'11'+locs[row['County'].upper().replace("'",'')].zfill(3),
					'name':row['Precinct Name'],
					'number':row['Precinct Code']})
		pollwriter.writerow({'id':polling_location_id,
					'address_location_name':row['Polling Place Name'],
					'address_line1':row['Polling Place Address'][:row['Polling Place Address'].rfind(",")],
					'address_city':row['Polling Place Address'][row['Polling Place Address'].rfind(",")+1:row['Polling Place Address'].find(' IA ')].strip(),
					'address_state':'IA',
					'address_zip':row['Polling Place Address']})
ss_count = 0
#print precincts
add_hashes = set([])
with open('street_segment.txt','w') as w:
	writer = DictWriter(w,fieldnames=['id','start_house_number','end_house_number','odd_even_both','non_house_address_street_direction','non_house_address_street_name','non_house_address_address_direction','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id'])
	writer.writeheader()
	for i in range(6):
		with open('vf{0}.csv'.format(i+1),'r') as r:
			reader = DictReader(r)
			for row in reader:
				hash_val = hash_list(row,['HOUSE_NUM','POST_DIR','STREET_NAME','PRE_DIR','CITY','ZIP_CODE','COUNTYWIDE','PRECINCT'])
				if hash_val in add_hashes:
					continue
				add_hashes.add(hash_val)
				ss_count += 1
				writer.writerow({'id':'88'+str(ss_count),
						'start_house_number':row['HOUSE_NUM'],
						'end_house_number':row['HOUSE_NUM'],
						'odd_even_both':'BOTH',
						'non_house_address_street_direction':row['POST_DIR'],
						'non_house_address_street_name':row['STREET_NAME'],
						'non_house_address_address_direction':row['PRE_DIR'],
						'non_house_address_city':row['CITY'],
						'non_house_address_state':'IA',
						'non_house_address_zip':row['ZIP_CODE'],
						'precinct_id':precincts[str((int(row['COUNTYWIDE'])*2)-1).zfill(3)+'*'+row['PRECINCT']]})

