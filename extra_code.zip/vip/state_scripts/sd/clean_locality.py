from csv import DictReader,DictWriter
localities = {}
with open('locality.txt','r') as r:
	reader = DictReader(r)
	for row in reader:
		localities[row['id']] = row['name']
with open('matches.csv','r') as r,open('matches_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['sourced_county'] = localities['11'+row['sourced_county'].zfill(3)]
		row['vf_precinct_county'] = localities['11'+row['vf_precinct_county'].zfill(3)]
		writer.writerow(row)
vf_count = 0
with open('ss.txt','r') as r,open('SD_vf_deduped.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['vf_id','house_number','zip','state','street_direction','street_name','street_suffix','address_direction','apartment_number','county','city','vf_precinct_id'])
	writer.writeheader()
	for row in reader:
		vf_count += 1
		writer.writerow({'vf_id':'88'+str(vf_count),
				'house_number':row['house_number'],
				'zip':row['zip'],
				'state':'SD',
				'street_direction':row['predirection'],
				'street_name':row['street_name'],
				'street_suffix':row['suffix'],
				'address_direction':row['postdirection'],
				'apartment_number':row['apartment_number'],
				'county':localities['11'+row['county'].zfill(3)],
				'city':row['city'],
				'vf_precinct_id':row['precinct_id']})
