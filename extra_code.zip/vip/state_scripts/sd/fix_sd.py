from csv import DictReader,DictWriter

prec_count = 0
with open('polling_location.txt','r') as r, open('processed_polling_location.csv','w') as pollw, open('processed_precinct.csv','w') as precw:
	reader = DictReader(r)
	pollwriter = DictWriter(pollw,fieldnames=['locality_id','polling_location_locality_count','polling_location_id','directions','polling_hours','photo_url','address_location_name','address_line1','address_line2','address_city','address_state','address_zip','source','INTERNAL_notes'])
	precwriter = DictWriter(precw,fieldnames=['locality_id','precinct_locality_count','precinct_id','county','county_fips','city','raw_precinct_name','clean_precinct_name','raw_precinct_number','clean_precinct_number','lowest_political_level','lowest_political_value','ward','mail_only','ballot_style_image_url','polling_location_ids','source','INTERNAL_notes'])
	pollwriter.writeheader()
	precwriter.writeheader()
	for row in reader:
		prec_count += 1
		pollwriter.writerow({'locality_id':row['CountyID'].zfill(3),
					'polling_location_locality_count':str(prec_count).zfill(4),
					'polling_location_id':'44'+row['CountyID'].zfill(3)+str(prec_count).zfill(4),
					'directions':'','polling_hours':'','photo_url':'',
					'address_location_name':row['PollingPlaceName'],
					'address_line1':row['PollingPlaceAddress'],
					'address_line2':'',
					'address_city':row['PollingPlaceCity'],
					'address_state':'SD',
					'address_zip':row['PollingPlaceZip'],
					'source':'','INTERNAL_notes':''})
		precwriter.writerow({'locality_id':row['CountyID'].zfill(3),
					'precinct_locality_count':str(prec_count).zfill(4),
					'precinct_id':'33'+row['CountyID'].zfill(3)+str(prec_count).zfill(4),
					'county':row['CountyID'],
					'county_fips':'',
					'city':'',
					'raw_precinct_name':row['PrecinctName'],
					'clean_precinct_name':row['PrecinctName'],
					'raw_precinct_number':row['StatePrecinctID'],
					'clean_precinct_number':row['StatePrecinctID'],
					'lowest_political_level':'','lowest_political_value':'','ward':'','mail_only':'','ballot_style_image_url':'',
					'polling_location_ids':'44'+row['CountyID'].zfill(3)+str(prec_count).zfill(4),
					'source':'','INTERNAL_notes':''})
