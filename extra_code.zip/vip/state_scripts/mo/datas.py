from csv import DictReader,DictWriter
import csv

files = ['VIP1.txt','VIP2.txt','VIP3.txt','VIP4.txt','VIP5.txt','VIP6.txt','VIP7.txt','VIP8.txt','VIP9.txt']
loc_count = 0
locs = {}
prec_count = 0
precs = {}
street_count = 0
issue_count = 0
streets = set([])
with open('locality.txt','w') as lw,open('precinct.txt','w') as pw,open('precinct_polling_location.txt','w') as ppw,open('polling_location.txt','w') as pollw,open('street_segment.txt','w') as ssw:
	locwriter = DictWriter(lw,fieldnames=['id','name','state_id','type'])
	precwriter = DictWriter(pw,fieldnames=['id','name','locality_id'])
	precpollwriter = DictWriter(ppw,fieldnames=['precinct_id','polling_location_id'])
	pollwriter = DictWriter(pollw,fieldnames=['id','address_location_name','address_line1','address_city','address_state','address_zip'])
	sswriter = DictWriter(ssw,fieldnames=['id','precinct_id','start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_street_name','non_house_address_city','non_house_address_street_suffix','non_house_address_state','non_house_address_street_direction','non_house_address_zip'])
	locwriter.writeheader()
	precwriter.writeheader()
	precpollwriter.writeheader()
	pollwriter.writeheader()
	sswriter.writeheader()
	for f in files:
		with open(f,'r') as r:
			reader = csv.reader(r,delimiter='|')
			for row in reader:
			#	print row
				try:
					if row[14] not in locs:
						loc_count += 1
						locs[row[14]] = '11'+str(loc_count)
						locwriter.writerow({'id':locs[row[14]],
								'name':row[14],
								'state_id':'29'})
					if row[1] not in precs:
						prec_count += 1
						precs[row[1]] = '33' + str(prec_count)
						precwriter.writerow({'id':precs[row[1]],
								'name':row[1],
								'locality_id':locs[row[14]]})
						precpollwriter.writerow({'precinct_id':'33'+str(prec_count),
									'polling_location_id':'44'+str(prec_count)})
						pollwriter.writerow({'id':'44'+str(prec_count),
									'address_location_name':row[15],
									'address_line1':row[16],
									'address_city':row[17],
									'address_state':'MO',
									'address_zip':row[19]})
					street_val = row[2]+'*'+row[4]+'*'+row[5]+'*'+row[6]+'*'+row[8]+'*'+row[10]+'*'+row[12]+'*'+row[1]
					if street_val in streets:
						continue
					streets.add(street_val)
					street_count += 1
					sswriter.writerow({'id':'88'+str(street_count),
								'precinct_id':precs[row[1]],
								'start_house_number':row[2],
								'end_house_number':row[2],
								'odd_even_both':'BOTH',
								'start_apartment_number':row[8],
								'end_apartment_number':row[8],
								'non_house_address_street_name':row[5],
								'non_house_address_city':row[10],
								'non_house_address_street_suffix':row[6],
								'non_house_address_state':'MO',
								'non_house_address_street_direction':row[4],
								'non_house_address_zip':row[12]})
				except:
					issue_count += 1
print issue_count
