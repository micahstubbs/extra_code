import csv

data = csv.DictReader(open("voter_file.txt"))

precinct_codes = {}

for row in data:
	county = row["county"]
	if county in precinct_codes:
		if not row["precinct_name"] in precinct_codes[county]:
			precinct_codes[county].append(row["precinct_name"])
	else:
		precinct_codes[county] = []
		precinct_codes[county].append(row["precinct_name"])
print precinct_codes
