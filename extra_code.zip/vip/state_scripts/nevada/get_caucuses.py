import csv
import MySQLdb as mdb

connection = mdb.connect('localhost', 'vip', 'password', 'vip')
cursor = connection.cursor(mdb.cursors.DictCursor)

def get_precincts(data):
	precinct_info = {}
	for row in data:
		county = row["county"]
		name = int(float(row["precinct_name"]))
		name = name if name < 100000 else (name/100000)
		if county not in precinct_info:
			precinct_info[county] = []
		precinct_info[county].append(name)
	for county in precinct_info:
		precinct_info[county] = list(set(precinct_info[county]))
	return precinct_info

voter_data = csv.DictReader(open("voter_file.txt"))

precinct_codes = get_precincts(voter_data)

#might pull the precinct_name cleaning code into a separate function
#also, a better way to not add duplicate codes, other than check if in?
for row in voter_data:
	county = row["county"]
	code = int(float(row["precinct_name"]))
	code = code if code < 100000 else (code/100000)

	if county in precinct_codes:
		if not code in precinct_codes[county]:
			precinct_codes[county].append(code)
	else:
		precinct_codes[county] = []
		precinct_codes[county].append(code)

caucus_data = csv.DictReader(open("nevada_caucuses.txt"))

counties = {}
cursor.execute("SELECT * from locality")
rows = cursor.fetchall()
for r in rows:
	counties[r["name"]] = r["id"]

precincts = []
polling_locations = []

for row in caucus_data:
	county = row["County"]
	precinct_list = row["Precincts"]
	if len(row["County"]) <= 0:
		continue

	if len(precinct_list) <= 0 or precinct_list == "All":
		for name in precinct_codes[county]:
			data = {"locality_id":counties[county], "name":name}
			precincts.append(data)
	else:
		precinct_names = precinct_list.split(",")
		for name in precinct_names:
			if len(name) > 0:
				data = {"locality_id":counties[county], "name":name}
				precincts.append(data)
	polling = {}
	polling["address_location_name"] = row["Location"]
	polling["polling_hours"] = row["Time"]
	address = row["Address"].split(",")
	if len(address) >= 1:
		polling["address_line1"] = address[0]
	if len(address) >= 2:
		polling["address_city"] = address[1]
	if len(address) >= 3:
		polling["address_zip"] = address[2].replace("NV", "").strip()
	polling_locations.append(polling)

for p in precincts:
	if p["locality_id"] == '3211':
		print p
print polling_locations
