import csv
import MySQLdb
import MySQLdb.cursors
from lxml import etree
import codecs

connection = MySQLdb.connect('localhost', 'nevada', 'password', 'nevada', cursorclass=MySQLdb.cursors.DictCursor)
cursor = connection.cursor()

schemaUrl = "http://election-info-standard.googlecode.com/files/vip_spec_v3.0xsd"

print "creating vipObject..."
	
NS = 'http://www.w3.org/2001/XMLSchema-instance'
location_attribute = '{%s}noNamespaceSchemaLocation' % NS
	
# -*- coding: utf-8 -*-

vipObj = etree.Element('vip_object', attrib={location_attribute: schemaUrl})
vipObj.set("schemaVersion","3.0")
	
print "finished creating vipObject"

cursor.execute("SELECT * FROM locality")
results = cursor.fetchall()

for r in results:
	element = etree.SubElement(vipObj, "locality")
	element.set("id", str(r["id"]))
	subelem1 = etree.SubElement(element, "name")
	subelem1.text = r["name"]
	subelem2 = etree.SubElement(element, "state_id")
	subelem2.text = str(r["state_id"])
	subelem3 = etree.SubElement(element, "type")
	subelem3.text = r["type"]

cursor.execute("SELECT * FROM precinct")
results = cursor.fetchall()

for r in results:
	element = etree.SubElement(vipObj, "precinct")
	element.set("id", str(r["id"]))
	subelem1 = etree.SubElement(element, "name")
	subelem1.text = r["name"]
	subelem3 = etree.SubElement(element, "locality_id")
	subelem3.text = str(r["locality_id"])
	subelem3 = etree.SubElement(element, "polling_location_id")
	subelem3.text = str(r["polling_location_id"])

cursor.execute("SELECT * FROM polling_location")
results = cursor.fetchall()

for r in results:
	element = etree.SubElement(vipObj, "polling_location")
	element.set("id", str(r["id"]))
	#subelem1 = etree.SubElement(element, "polling_hours")
	#subelem1.text = r["polling_hours"]
	cursor.execute("SELECT * FROM simpleAddressType where id = " + str(r["address_id"]))
	address = cursor.fetchall()
	for a in address:
		address = etree.SubElement(element, "address")
		address_elem1 = etree.SubElement(address, "location_name")
		address_elem1.text = a["location_name"]
		address_elem2 = etree.SubElement(address, "line1")
		print a["line1"]
		address_elem2.text = a["line1"]
		address_elem3 = etree.SubElement(address, "city")
		address_elem3.text = a["city"]
		address_elem4 = etree.SubElement(address, "state")
		address_elem4.text = "NV"
		address_elem5 = etree.SubElement(address, "zip")
		address_elem5.text = str(a["zip"])

f = open("NV_feed.xml", "w")
f.write(etree.tostring(vipObj, pretty_print=True, xml_declaration=True, encoding="utf-8"))
f.close()
