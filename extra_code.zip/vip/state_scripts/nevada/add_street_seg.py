from lxml import etree
import csv
import MySQLdb
import MySQLdb.cursors
import codecs

TEMPLATE = "street.tmpl"

connection = MySQLdb.connect('localhost', 'nevada', 'password', 'nevada', cursorclass=MySQLdb.cursors.DictCursor)
cursor = connection.cursor()

cursor.execute("SELECT * FROM street_segment")
street_segments = cursor.fetchall()

template = open("street.tmpl","r").read()
w = open("NV_feed.xml", "a")

for street in street_segments:
	line = {'id':street["id"], 'start_house_number':street["start_house_number"], 'end_house_number':street["end_house_number"], 'odd_even_both':street["odd_even_both"]}
	if street["start_apartment_number"] > 0:
		line["start_apartment_number"] = street["start_apartment_number"]
		line["end_apartment_number"] = street["end_apartment_number"]
	else:
		line["start_apartment_number"] = ''
		line["end_apartment_number"] = ''

	line["precinct_id"] = street["precinct_id"]
	
	cursor.execute("SELECT * from detailAddressType where id = " + str(street["non_house_address_id"]))
	address = cursor.fetchall()

	for a in address:
		line["street_direction"] = a["street_direction"]
		line["street_name"] = a["street_name"]
		line["street_suffix"] = a["street_suffix"]
		line["city"] = a["city"]
		line["state"] = a["state"]
		if len(a["zip"]) < 5:
			line["zip"] = 00000
		else:
			line["zip"] = a["zip"]
	element = etree.XML(template.format(**line))
	for parent in element[:]:
		for child in parent[:]:
			if child in parent and child.text is None and len(child) == 0:
				parent.remove(child)
		if parent in element and parent.text is None and len(parent) == 0:
			element.remove(parent)

	w.write(etree.tostring(element) + "\n")
		
