from csv import DictReader,DictWriter

locs = {}
loc_count = 0
with open('locality.csv','r') as r, open('locality.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		loc_count += 1
		locs[row['election_administration_id']] = '1111' + str(loc_count)
		writer.writerow({'id':'1111'+str(loc_count),
				'name':row['name'],
				'state_id':row['state_id'],
				'type':'County',
				'election_administration_id':'2222'+str(loc_count)})
with open('election_administration.csv','r') as r, open('election_administration.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['id'] = '2222' + locs[row['eo_id']][4:]
		row['eo_id'] = ''
		writer.writerow(row)

with open('Locations.VIP.csv','r') as r, open('early_vote_site.txt','w') as ew, open('locality_early_vote_site.txt','w') as lw:
	reader = DictReader(r)
	locwriter = DictWriter(lw,fieldnames=['locality_id','early_vote_site_id'])
	earlywriter = DictWriter(ew,fieldnames=['address_location_name','address_line1','address_line2','address_city','address_state','address_zip','directions','id'])
	locwriter.writeheader()
	earlywriter.writeheader()
	for row in reader:
		locwriter.writerow({'locality_id':row['locality_id'],
					'early_vote_site_id':'9999'+row['id']})
		earlywriter.writerow({'address_location_name':row['address_location_name'],
					'address_line1':row['address_line1'],
					'address_line2':row['address_line2'],
					'address_city':row['address_city'],
					'address_state':'WA',
					'address_zip':row['address_zip'],
					'directions':row['directions'],
					'id':'9999'+row['id']})
precincts = {}
prec_count = 0
with open('precinct.csv','r') as r, open('precinct.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['id','locality_id','name','number','ward'])
	writer.writeheader()
	for row in reader:
		prec_count += 1
		writer.writerow({'id':'3333'+str(prec_count),
					'locality_id':locs[row['county']],
					'name':row['name'],
					'number':row['number'],
					'ward':row['ward']})
		precincts[locs[row['county']]+'*'+row['number']+'*'+row['ward']] = '3333'+str(prec_count)
bad_count = 0
with open('ss.txt','r') as r, open('street_segment.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_address_direction', 'non_house_address_house_number_prefix', 'non_house_address_house_number_suffix','non_house_address_street_direction','non_house_address_street_name','non_house_address_street_suffix','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id','id'])
	writer.writeheader()
	for row in reader:
		row.pop('non_house_address_apartment')
		row.pop('non_house_address_house_number')
		prec_info = locs[row.pop('CountyCode')]+'*'+row.pop('precinct_id')+'*'+row.pop('precinct_split_id')
		if prec_info in precincts:
			row['precinct_id'] = precincts[prec_info]
		else:
			bad_count += 1
			row['precinct_id'] = '55555555555'
		writer.writerow(row)
print bad_count
