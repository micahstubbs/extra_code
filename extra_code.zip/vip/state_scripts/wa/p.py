from csv import DictReader,DictWriter

precincts = set([])
with open('precinct.csv','r') as r,open('precinct.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['id','county','name','number','ward'])
	writer.writeheader()
	p_count = 0
	for row in reader:
		if row['CountyCode']+'*'+row['PrecinctCode']+'*'+row['PrecinctPart'] not in precincts:
			p_count += 1
			precincts.add(row['CountyCode']+'*'+row['PrecinctCode']+'*'+row['PrecinctPart'])
			writer.writerow({'id':'22'+str(p_count),
						'county':row['CountyCode'],
						'name':row['PrecinctName'],
						'number':row['PrecinctCode'],
						'ward':row['PrecinctPart']})
print len(precincts)
