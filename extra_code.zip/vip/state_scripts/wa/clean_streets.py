from csv import DictReader, DictWriter
from hashlib import md5

def hash_list(row,fields):
	m = md5()
	for f in fields:
		m.update(row[f])
	return m.hexdigest()

ss_count = 0
add_hashes = set([])
with open('street_segment2.txt','r') as r, open('ss.txt','w') as w:
	reader = DictReader(r)
	fields = reader.fieldnames
	writer = DictWriter(w,fieldnames=fields)
	writer.writeheader()
	for row in reader:
		row['non_house_address_apartment'] = ''
		row['id'] = ''
		hash_val = hash_list(row,fields)
		if hash_val in add_hashes:
			continue
		add_hashes.add(hash_val)
		ss_count += 1
		row['id'] = '88' + str(ss_count)
		writer.writerow(row)
