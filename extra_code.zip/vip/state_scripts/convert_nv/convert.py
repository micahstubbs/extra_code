from csv import DictReader, DictWriter
from hashlib import md5

fields = ["voterbase_id","tsmart_exact_track","tsmart_exact_address_track","tsmart_full_address","tsmart_city","tsmart_state","tsmart_zip","tsmart_zip4","tsmart_street_number","tsmart_pre_directional","tsmart_street_name","tsmart_street_suffix","tsmart_post_directional","tsmart_unit_designator","tsmart_secondary_number","tsmart_address_usps_address_code","tsmart_address_carrier_route","tsmart_address_dpv_confirm_code","tsmart_address_dpv_footnote","vf_source_state","vf_county_code","vf_county_name","vf_CD","vf_SD","vf_HD","vf_township","vf_ward","vf_precinct_id","vf_precinct_name","vf_county_council","vf_city_council","vf_municipal_district","vf_school_district","vf_judicial_district","tsmart_county_code","tsmart_county_name","tsmart_CD","tsmart_SD","tsmart_HD","tsmart_township","tsmart_ward","tsmart_precinct_id","tsmart_precinct_name","tsmart_county_council","tsmart_city_council","tsmart_municipal_district","tsmart_school_district","tsmart_judicial_district","tsmart_latitude","tsmart_longitude","tsmart_level","tsmart_census_id","tsmart_DMA","tsmart_DMA_Name","tsmart_place","tsmart_place_name","reg_latitude","reg_longitude","reg_level","reg_census_id","reg_dma","reg_dma_name","reg_place","reg_place_name","vf_voterfile_update_date","tsmart_address_deliverability_indicator","tsmart_address_improvement_type","tsmart_dwelling_type","vf_reg_address_1","vf_reg_address_2","vf_reg_city","vf_reg_state","vf_reg_zip","vf_reg_zip4","vf_reg_cass_address_full","vf_reg_cass_city","vf_reg_cass_state","vf_reg_cass_zip","vf_reg_cass_zip4","vf_reg_cass_street_num","vf_reg_cass_pre_directional","vf_reg_cass_street_name","vf_reg_cass_street_suffix","vf_reg_cass_post_directional","vf_reg_cass_unit_designator","vf_reg_cass_apt_num","reg_address_usps_address_code","reg_address_carrier_route","reg_address_dpv_confirm_code","reg_address_dpv_footnote","vf_mail_street","vf_mail_City","vf_mail_State","vf_mail_zip5","vf_mail_zip4","vf_mail_house_number","vf_mail_pre_direction","vf_mail_street_name","vf_mail_street_type","vf_mail_post_direction","vf_mail_apt_type","vf_mail_apt_num"]

translate = {'portion':'vf_ward','precinct':'vf_precinct_id','precinct_name':'vf_precinct_name','city':'vf_reg_cass_city','state':'vf_reg_cass_state','zip':'vf_reg_cass_zip','house_number':'vf_reg_cass_street_num','pre_dir':'vf_reg_cass_pre_directional','street':'vf_reg_cass_street_name','type':'vf_reg_cass_street_suffix','post_dir':'vf_reg_cass_post_directional','apartment_number':'vf_reg_cass_apt_num'}

def hash_list(row,keys):
	m = md5()
	for key in keys:
		m.update(row[key] + '*')
	return m.hexdigest()

with open('VIP_CA_NevadaCo3_2012-09-26.txt','r') as r, open('Nevada_County_CA.txt','w') as w:
	reader = DictReader(r,dialect='excel-tab')
	writer = DictWriter(w,dialect='excel-tab',fieldnames=fields)
	writer.writeheader()
	vf_hashes = set([])
	for row in reader:
		vf_hash = hash_list(row,translate.keys())
		if vf_hash not in vf_hashes:
			vf_hashes.add(vf_hash)
			output = {}
			for f in fields:
				output[f] = ""
			for k,v in translate.iteritems():
				output[v] = row[k]
			output['voterbase_id'] = row['voter_id']
			output['vf_source_state'] = 'CA'
			output['vf_county_name'] = 'NEVADA'
			output['vf_county_code'] = '32'
			writer.writerow(output)
			
