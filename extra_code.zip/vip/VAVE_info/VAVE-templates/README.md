VAVE-templates
==============

Examples of VAVE data and reporting templates