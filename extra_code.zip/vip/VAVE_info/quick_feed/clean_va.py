from csv import DictReader, DictWriter
from hashlib import md5

hash_list = ['start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_house_number','non_house_address_house_number_prefix','non_house_address_house_number_suffix','non_house_address_street_direction','non_house_address_street_name','non_house_address_street_suffix','non_house_address_address_direction','non_house_address_apartment','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id','precinct_split_id']

def get_hash(row, field_list):
	m = md5()
	for field in field_list:
		m.update(row[field])
	return m.hexdigest()

segments = set([])
with open('feed_data/vip_VA/street_segment.txt','r') as r,  open('feed_data/vip_VA/street_segment_deduped.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		seg_hash = get_hash(row, hash_list)
		if seg_hash not in segments:
			segments.add(seg_hash)
			writer.writerow(row)
