from csv import DictReader, DictWriter

precincts = {}

with open('feed_data/vip_MS/precinct_polling_location.txt','r') as r:
	reader = DictReader(r)
	for row in reader:
		precincts[row['polling_location_id']] = row['precinct_id']

with open('feed_reports/vip_MS/feed_errors.txt','r') as r, open('missing_polling_locations.csv','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=['polling_location_id','precinct_id'])
	writer.writeheader()
	for row in reader:
		if row['id'] in precincts:
			writer.writerow({'polling_location_id':row['id'],
						'precinct_id':precincts[row['id']]})
