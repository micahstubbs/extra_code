from csv import DictReader, DictWriter

with open('feed_data/vip_OK/precinct_fixed.txt','r') as r, open('feed_data/vip_OK/precinct.txt','w') as w:
		reader = DictReader(r)
		writer = DictWriter(w, fieldnames=reader.fieldnames)
		writer.writeheader()
		for row in reader:
			row['locality_id'] = '11' + row['locality_id']
			writer.writerow(row)

with open('feed_data/vip_OK/street_segment_fixed.txt','r') as r, open('feed_data/vip_OK/street_segment.txt','w') as w:
		reader = DictReader(r)
		writer = DictWriter(w, fieldnames=reader.fieldnames)
		writer.writeheader()
		for row in reader:
			row['precinct_id'] = '44' + row['precinct_id']
			writer.writerow(row)
