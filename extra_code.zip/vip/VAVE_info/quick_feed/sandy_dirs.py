from csv import DictReader,DictWriter
with open('feed_data/vip_CT/polling_location.txt','r') as r, open('feed_data/vip_CT/polling_location.csv','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['directions'] = 'This information was last updated on 11/4 to reflect Hurricane Sandy related polling place changes'
		writer.writerow(row)
