from csv import DictReader
county_list = ['Butte','Calaveras','Colusa','Contra Costa','Fresno','Inyo','Marin','Orange','Plumas','Riverside','Sacramento','San Benito','San Mateo','Santa Cruz','Shasta','Tehama','Tulare','Ventura','Yuba']
output = "## {0} County, California General Election\ndata {{\n  nid: {1}\n  election_id: 4000\n  title: \"{0} County, California 2012 General Election\"\n  feed_url: \"https://data.votinginfoproject.org/feeds/{3}/vipFeed-{2}-2012-11-06.zip\"\n  user: \"jared@votinginfoproject.org\"\n}}\n\n"
nid = 3144

with open('fips.csv', 'r') as r, open('proto.txt','w') as w:
	reader = DictReader(r)
	for row in reader:
		if row['State'] == 'CA' and row['Cty'].replace('_',' ') in county_list:
			nid += 1
			w.write(output.format(row['Cty'],nid,row['Fips5'],row['State'].lower()))
