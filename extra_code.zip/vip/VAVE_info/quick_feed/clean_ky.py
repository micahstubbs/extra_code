from csv import DictReader, DictWriter
from hashlib import md5

#1371160, next line has control char

PREFIX = '88'

def get_hash(row, field_list):
	m = md5()
	for field in field_list:
		m.update(row[field])
	return m.hexdigest()

with open('feed_data/old_KY/addresses.txt','r') as r, open('feed_data/vip_KY/street_segment.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=['start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_street_direction','non_house_address_street_name','non_house_address_street_suffix','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id','id'])
	writer.writeheader()
	count = 0
	address_hashes = set([])
	for row in reader:
		add_hash = get_hash(row,['precinct_id','city','state','zip','street_suffix','street_name','street_type','streeet_apt','house_number'])
		if add_hash in address_hashes:
			continue
		address_hashes.add(add_hash)
		count += 1
		output = {'id':PREFIX+str(count),
				'start_house_number':row['house_number'],
				'end_house_number':row['house_number'],
				'odd_even_both':'both',
				'start_apartment_number':row['streeet_apt'].replace("APT ","").replace("LOT ", "").replace("#","").replace("NONE","").replace("N/A","").replace("-","").replace("NA","").replace("RD","").replace("APT. ","").replace("UNIT ",""),
				'end_apartment_number':row['streeet_apt'].replace("APT ","").replace("LOT ","").replace("#","").replace("NONE","").replace("N/A","").replace("-","").replace("NA","").replace("RD","").replace("APT. ","").replace("UNIT ",""),
				'non_house_address_street_direction':row['street_prefix'],
				'non_house_address_street_name':row['street_name']+" "+row['street_type'],
				'non_house_address_street_suffix':row['street_suffix'],
				'non_house_address_city':row['city'],
				'non_house_address_state':row['state'],
				'non_house_address_zip':row['zip'],
				'precinct_id':str(row['precinct_id'][:2]) + str(row['precinct_id'][3:])}
		writer.writerow(output)
		
