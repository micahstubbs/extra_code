from csv import DictReader,DictWriter

with open('feed_data/vip_DC/precinct.txt','r') as r, open('feed_data/vip_DC/precinct_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['locality_id'] = '111'
		row['id'] = '44' + row['id'][4:]
		writer.writerow(row)

with open('feed_data/vip_DC/precinct_split.txt','r') as r, open('feed_data/vip_DC/precinct_split_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['precinct_id'] = '44' + row['precinct_id'][4:]
		row['id'] = '55' + row['id'][4:]
		writer.writerow(row)

with open('feed_data/vip_DC/precinct_split_electoral_district.txt','r') as r, open('feed_data/vip_DC/precinct_split_electoral_district_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['precinct_split_id'] = '55' + row['precinct_split_id'][4:]
		row['electoral_district_id'] = '77' + row['electoral_district_id'][4:]
		writer.writerow(row)

with open('feed_data/vip_DC/polling_location.txt','r') as r, open('feed_data/vip_DC/polling_location_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['id'] = '66' + row['id'][4:]
		row['directions'] = ''
		writer.writerow(row)

with open('feed_data/vip_DC/precinct_polling_location.txt','r') as r, open('feed_data/vip_DC/precinct_polling_location_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['precinct_id'] = '44' + row['precinct_id'][4:]
		row['polling_location_id'] = '66' + row['polling_location_id'][4:]
		writer.writerow(row)

with open('feed_data/vip_DC/early_vote_site.txt','r') as r, open('feed_data/vip_DC/early_vote_site_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['id'] = '99' + row['id'][4:]
		writer.writerow(row)

with open('feed_data/vip_DC/locality_early_vote_site.txt','r') as r, open('feed_data/vip_DC/locality_early_vote_site_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['locality_id'] = '111'
		row['early_vote_site_id'] = '99' + row['early_vote_site_id'][4:]
		writer.writerow(row)

with open('feed_data/vip_DC/street_segment.txt','r') as r, open('feed_data/vip_DC/street_segment_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['id'] = '88' + row['id'][4:]
		row['precinct_id'] = '44' + row['precinct_id'][4:]
		row['precinct_split_id'] = '55' + row['precinct_split_id'][4:]
		writer.writerow(row)

with open('feed_data/vip_DC/electoral_district.txt','r') as r, open('feed_data/vip_DC/electoral_district_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['id'] = '77' + row['id'][4:]
		writer.writerow(row)
