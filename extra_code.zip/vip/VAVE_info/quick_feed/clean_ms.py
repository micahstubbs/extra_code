from csv import DictReader, DictWriter

with open('feed_data/old_MS/03_Locality.csv','r') as r, open('feed_data/vip_MS/locality.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=['id','name','state_id','type'])
	writer.writeheader()
	for row in reader:
		writer.writerow({'id':row['LOCALITY_ID'],
					'name':row['NAME'],
					'state_id':'28',
					'type':row['TYPE']})

with open('feed_data/old_MS/04_Precinct.csv','r') as r, open('feed_data/vip_MS/precinct.txt','w') as pw, open('feed_data/vip_MS/precinct_polling_location.txt','w') as ppw:
	reader = DictReader(r)
	prec_writer = DictWriter(pw, fieldnames=['id','name','locality_id'])
	precpoll_writer = DictWriter(ppw, fieldnames=['precinct_id','polling_location_id'])
	prec_writer.writeheader()
	precpoll_writer.writeheader()
	for row in reader:
		prec_writer.writerow({'id':row['ID'],
					'name':row['NAME'],
					'locality_id':row['LOCALITY_ID']})
		precpoll_writer.writerow({'precinct_id':row['ID'],
						'polling_location_id':row['POLLING_LOCATION_ID']})
#with open('feed_data/vip_MS/05_Precinct_Split.csv','r') as r, open('feed_data/vip_MS/precinct_split.txt','w') as psw:
#	reader = DictReader(r)
#	precsplit_writer = DictWriter(psw, fieldnames=['id','name'
with open('feed_data/old_MS/13_Polling_Location.csv','r') as r, open('feed_data/vip_MS/polling_location.txt','w') as pw:
	reader = DictReader(r)
	poll_writer = DictWriter(pw, fieldnames=['id','address_location_name','address_line1','address_city','address_state','address_zip'])
	poll_writer.writeheader()
	poll_ids = set([])
	for row in reader:
		if row['ID'] in poll_ids:
			continue
		poll_ids.add(row['ID'])
		poll_writer.writerow({'id':row['ID'],
					'address_location_name':row['LOCATION_NAME'],
					'address_line1':row['LINE1'],
					'address_city':row['CITY'],
					'address_state':row['STATE'],
					'address_zip':row['ZIP']})

with open('feed_data/old_MS/14_Street_Segement.csv','r') as r, open('feed_data/vip_MS/street_segment.txt','w') as sw:
	reader = DictReader(r)
	street_writer = DictWriter(sw, fieldnames=['id','start_house_number','end_house_number','odd_even_both','non_house_address_street_direction','non_house_address_street_name','non_house_address_street_suffix','non_house_address_address_direction','non_house_address_state','non_house_address_city','non_house_address_zip','precinct_id'])
	street_writer.writeheader()
	for row in reader:
		street_writer.writerow({'id':row['STREET_SEGMENT_ID'],
					'start_house_number':row['START_HOUSE_NUMBER'],
					'end_house_number':row['END_HOUSE_NUMBER'],
					'odd_even_both':row['ODD_EVEN_BOTH'],
					'non_house_address_street_direction':row['STREET_DIRECTION'],
					'non_house_address_street_name':row['STREET_NAME'],
					'non_house_address_street_suffix':row['STREET_SUFFIX'],
					'non_house_address_address_direction':row['ADDRESS_DIRECTION'],
					'non_house_address_state':row['STATE'],
					'non_house_address_city':row['City'],
					'non_house_address_zip':row['Zip'],
					'precinct_id':row['PRECINCT_ID']})
