from csv import DictReader, DictWriter

poll_count = 0
polls = {}
with open('sandy_PollSite_Active_Export_20121104.txt','r') as r, open('polling_location.txt','w') as w:
	reader = DictReader(r,delimiter='|')
	writer = DictWriter(w,fieldnames=['id','address_location_name','address_line1','address_city','address_state','address_zip'])
	writer.writeheader()
	for row in reader:
		poll_count += 1
		poll_id = '44' + str(poll_count)
		polls[row['SITE_NUMBER']] = poll_id
		writer.writerow({'id':poll_id,
				'address_location_name':row['SITE_NAME'],
				'address_line1':(row['STREET_NUMBER']+' '+row['STREET_NAME']+' '+row['STREET_SUFFIX']).strip(),
				'address_city':row['CITY'],
				'address_state':'NY',
				'address_zip':row['ZIP_CODE']})
precincts = {}
prec_count = 0
with open('sandy_EDAD_Export_20121104.txt','r') as r, open('precinct.txt','w') as pw, open('precinct_polling_location.txt','w') as ppw:
	reader = DictReader(r,delimiter='|')
	precwriter = DictWriter(pw,fieldnames=['id','locality_id','name','number'])
	precpollwriter = DictWriter(ppw,fieldnames=['precinct_id','polling_location_id'])
	precwriter.writeheader()
	precpollwriter.writeheader()
	for row in reader:
		prec_count += 1
		prec_id = '33' + str(prec_count)
		precincts[row['AD']+row['ED']] = prec_id
		if 77 <= int(row['AD']) <= 87:
			loc_id = 11005
		elif 41 <= int(row['AD']) <= 64:
			loc_id = 11047
		elif 65 <= int(row['AD']) <= 76:
			loc_id = 11061
		elif 23 <= int(row['AD']) <= 40:
			loc_id = 11081
		else:
			loc_id = 11085
		precpollwriter.writerow({'precinct_id':prec_id,
					'polling_location_id':polls[row['SITE_NUMBER']]})
		precwriter.writerow({'id':prec_id,
					'locality_id':loc_id,
					'name':row['AD']+row['ED'],
					'number':row['AD']+row['ED']})
with open('streets.txt','r') as r,open('street_segment.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		try:
			int(row['precinct_id'])
		except:
			continue
		row['precinct_id'] = precincts[row['precinct_id']]
		writer.writerow(row)
