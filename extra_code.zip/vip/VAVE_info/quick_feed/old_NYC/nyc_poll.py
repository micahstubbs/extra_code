from csv import DictReader, DictWriter

precinct_ids = {}
with open('processed_precinct.csv', 'r') as r,open('precinct.txt','w') as w,open('precinct_polling_location.txt','w') as pp_w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['id','locality_id','name','number'])
	writer.writeheader()
	precpoll_writer = DictWriter(pp_w,fieldnames=['precinct_id','polling_location_id'])
	precpoll_writer.writeheader()
	for row in reader:
		precinct_ids[row['clean_precinct_name']] = row['precinct_id']
		writer.writerow({'id':row['precinct_id'],
					'locality_id':'11'+row['locality_id'],
					'name':row['clean_precinct_name'],
					'number':row['clean_precinct_number']})
		precpoll_writer.writerow({'precinct_id':row['precinct_id'],
						'polling_location_id':row['polling_location_ids']})

with open('processed_polling_location.csv','r') as r, open('polling_location.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['id','directions','polling_hours','photo_url','address_location_name','address_line1','address_line2','address_city','address_state','address_zip'])
	writer.writeheader()
	for row in reader:
		row.pop('locality_id')
		row.pop('polling_location_locality_count')
		row['id'] = row.pop('polling_location_id')
		row.pop('source')
		row.pop('INTERNAL_notes')
		writer.writerow(row)

with open('street_segment.txt','r') as r, open('street_segment_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		try:
			int(row['precinct_id'])
		except:
			continue
		row['precinct_id'] = precinct_ids[row['precinct_id']]
		writer.writerow(row)
