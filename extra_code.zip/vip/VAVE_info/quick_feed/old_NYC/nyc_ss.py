from csv import DictWriter

count = 0
files = ['bkdata.txt','bxdata.txt','mndata.txt','qndata.txt','sidata.txt']
city_dict = {'bkdata.txt':'Brooklyn','bxdata.txt':'Bronx','mndata.txt':'New York','qndata.txt':'Queens','sidata.txt':'Staten Island'}
with open('street_segment.txt','w') as w:
	writer = DictWriter(w, fieldnames=['id','start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_street_name','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id'])
	writer.writeheader()
	for f_name in files:
		with open(f_name,'r') as f:
			for row in f:
				output = {}
				try:
					if len(row[52:59].strip()) > 0:
						start = row[52:59].strip()
						end = row[37:44].strip()
						if start.find("-") > 0:	
							output['start_house_number'] = str(int(start.replace('-','')))
							output['start_apartment_number'] = ''
							output['end_house_number'] = str(int(end.replace('-','')))
							output['end_apartment_number'] = ''
						else:
							output['start_house_number'] = str(int(start))
							output['end_house_number'] = str(int(end))
							if len(row[59:67].strip()) > 0:
								output['start_apartment_number'] = str(int(row[59:67].strip()))
								output['end_apartment_number'] = str(int(row[44:52].strip()))
							else:
								output['start_apartment_number'] = ''
								output['end_apartment_number'] = ''
					else:
						output['start_house_number'] = ''
						output['end_house_number'] = ''
						output['start_apartment_number'] = ''
						output['end_apartment_number'] = ''
				except:
					print "fuck"
					continue
				count += 1
				output['id'] = '88' + str(count)
				if row[36:37] == 'O':
					output['odd_even_both'] = 'ODD'
				elif row[36:37] == 'E':
					output['odd_even_both'] = 'EVEN'
				else:
					output['odd_even_both'] = 'BOTH'
				output['non_house_address_street_name'] = row[1:36].strip()
				output['non_house_address_city'] = city_dict[f_name]
				output['non_house_address_state'] = 'NY'
				output['non_house_address_zip'] = row[67:72].strip()
				output['precinct_id'] = row[75:77].strip() + row[72:75].strip()
				writer.writerow(output)
