from csv import DictReader, DictWriter

with open('feed_data/vip_DC/street_segment.txt','r') as r, open('feed_data/vip_DC/street_segment_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['odd_even_both'] = 'both'
		row['start_house_number'] = row['start_house_number'].strip()
		row['end_house_number'] = row['end_house_number'].strip()
		writer.writerow(row)
