from csv import DictReader, DictWriter

fix_dict = {'locality':'11',
		'election_administration':'22',
		'precinct':'44',
		'polling_location':'55',
		'street_segment':'88',
		'early_vote_site':'99'}

for f,p in fix_dict.iteritems():
	with open('feed_data/vip_OK/{0}.txt'.format(f),'r') as r, open('feed_data/vip_OK/{0}_fixed.txt'.format(f),'w') as w:
		reader = DictReader(r)
		writer = DictWriter(w, fieldnames=reader.fieldnames)
		writer.writeheader()
		for row in reader:
			row['id'] = p + row['id']
			writer.writerow(row)

with open('feed_data/vip_OK/precinct_polling_location.txt'.format(f),'r') as r, open('feed_data/vip_OK/precinct_polling_location_fixed.txt'.format(f),'w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['precinct_id'] = '44' + row['precinct_id']
		row['polling_location_id'] = '55' + row['polling_location_id']
		writer.writerow(row)
		
