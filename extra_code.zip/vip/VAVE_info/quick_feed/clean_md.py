import os

for f in os.listdir("feed_data/vip_MD/"):
	with open("feed_data/vip_MD/"+f, "r") as r, open("feed_data/vip_MD/"+f+"fixed", "w") as w:
		for line in r:
			w.write(line.strip()+"\n")
