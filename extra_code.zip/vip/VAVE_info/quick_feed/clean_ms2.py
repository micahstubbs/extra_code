from csv import DictReader, DictWriter
poll_data = {}
dup_polls = {}
with open('feed_data/vip_MS/polling_location.txt','r') as r:
	reader = DictReader(r)
	for row in reader:
		row_data = {'id':row['ID'],
				'address_location_name':row['ADDRESS_LOCATION_NAME'].replace('\n',''),
				'address_line1':row['ADDRESS_LINE1'].replace('\n',''),
				'address_city':row['ADDRESS_CITY'].replace('\n',''),
				'address_state':row['ADDRESS_STATE'].replace('\n',''),
				'address_zip':row['ADDRESS_ZIP'].replace('\n','')}
		if row['ID'] in poll_data:
			if row['ID'] not in dup_polls:
				dup_polls[row['ID']] = []
			dup_polls[row['ID']].append(row_data)
		else:
			poll_data[row['ID']] = row_data
for id_val in dup_polls:
	if id_val in poll_data:
		dup_polls[id_val].append(poll_data.pop(id_val))

with open('feed_data/vip_MS/polling_locations_good.txt','w') as w:
	writer = DictWriter(w,fieldnames=['id','address_location_name','address_line1','address_city','address_state','address_zip'])
	writer.writeheader()
	for id_val in poll_data:
		writer.writerow(poll_data[id_val])

with open('feed_data/vip_MS/polling_locations_dups.txt','w') as w:
	writer = DictWriter(w,fieldnames=['id','address_location_name','address_line1','address_city','address_state','address_zip'])
	writer.writeheader()
	for id_val in dup_polls:
		for row in dup_polls[id_val]:
			writer.writerow(row)

