import httplib, urllib, json
from poster.encode import multipart_encode
from poster.streaminghttp import register_openers
import urllib2

## {{{ http://code.activestate.com/recipes/146306/ (r1)
import mimetypes

def post_multipart(host, selector, fields, files):
    """
    Post fields and files to an http host as multipart/form-data.
    fields is a sequence of (name, value) elements for regular form fields.
    files is a sequence of (name, filename, value) elements for data to be uploaded as files
    Return the server's response page.
    """
    content_type, body = encode_multipart_formdata(fields, files)
    print content_type
    print body
    h = httplib.HTTPSConnection(host)
    header = {
        'User-Agent': 'Mozilla/5.0',
        'Content-Type': content_type
        }
    h.request('POST', selector, body, header)
    res = h.getresponse()
    return res.status, res.reason, res.read()

def encode_multipart_formdata(fields, files):
    """
    fields is a sequence of (name, value) elements for regular form fields.
    files is a sequence of (name, filename, value) elements for data to be uploaded as files
    Return (content_type, body) ready for httplib.HTTP instance
    """
    BOUNDARY = '----------ThIs_Is_tHe_bouNdaRY_$'
    CRLF = '\r\n'
    L = []
    for key, value in fields.iteritems():
        L.append('--' + BOUNDARY)
        L.append('Content-Disposition: form-data; name="%s"' % key)
        L.append('')
        L.append(value)
    print files
    for (key, filename, value) in files:
        L.append('--' + BOUNDARY)
        L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
        L.append('Content-Type: %s' % get_content_type(filename))
        L.append('')
        L.append(value)
    L.append('--' + BOUNDARY + '--')
    L.append('')
    body = CRLF.join(L)
    content_type = 'multipart/form-data; boundary=%s' % BOUNDARY
    return content_type, body

def get_content_type(filename):
    return mimetypes.guess_type(filename)[0] or 'application/octet-stream'
## end of http://code.activestate.com/recipes/146306/ }}}


setup_headers = {"Content-Type": "application/json", "Accept": "text/plain"}
conn = httplib.HTTPSConnection("px558.o1.gondor.io")
conn.request("GET", "/api/data/upload-request/", '', setup_headers)

response = conn.getresponse()

response_data = response.read()
print response_data

register_openers()

aws_setup = json.loads(response_data)
#aws_setup.update({'filename':'vipFeed-testconn.zip'})
status, reason, data = post_multipart("vavestatic.s3.amazonaws.com", "", aws_setup, [['vipFeed-testconn.zip', 'vipFeed-testconn.zip', "vipFeed-testconn.zip"]])
print status
print reason
print data
#request = urllib2.Request("http://vavestatic.s3.amazonaws.com/", datagen, headers)
#print urllib2.urlopen(request).read()
#aws_params = urllib.urlencode(aws_setup)
#add user agent?
#test with poster
#aws_headers = {'Content-Type':'multipart/form-data'}
#aws_conn = httplib.HTTPSConnection("vavestatic.s3.amazonaws.com")
#aws_conn.request("POST", "", aws_params, aws_headers)
#response = aws_conn.getresponse()
#print response.read()
print "random"

#aws_conn.close()
conn.close()
