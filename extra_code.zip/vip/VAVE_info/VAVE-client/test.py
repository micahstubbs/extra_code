import httplib, urllib, json

setup_headers = {"Content-Type": "application/json", "Accept": "text/plain"}
conn = httplib.HTTPSConnection("px558.o1.gondor.io")
conn.request("GET", "/api/data/upload-request/", '', setup_headers)

response = conn.getresponse()

response_data = response.read()
print response_data

aws_setup = json.loads(response_data)

aws_setup.update({'filename':'vipFeed-test.zip', 'file': open('vipFeed-test.zip','rb')})
print aws_setup
aws_params = urllib.urlencode(aws_setup)
#add user agent?
#test with poster
aws_headers = {'Content-Type':'multipart/form-data'}
aws_conn = httplib.HTTPSConnection("vavestatic.s3.amazonaws.com")
aws_conn.request("POST", "", aws_params, aws_headers)
response = aws_conn.getresponse()
print response.read()
print "random"

aws_conn.close()
conn.close()
