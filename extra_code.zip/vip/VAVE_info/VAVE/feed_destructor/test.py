def basic_select(table, vals=None, conditions=None):
	query = "SELECT "
	if not vals:
		query += " * "
	else:
		query += ','.join(vals)
	query += " FROM " + table
	if conditions:
		query += " WHERE " + ' AND '.join(["{0} {1} '{2}'".format(k,conditions[k]['condition'],conditions[k]['compare_to']) if condtions[k]['condition'] != 'not in' else "{0} {1} ({2})".format(k,conditions[k]['conditions'],basic_selectfor k in conditions])
	return query

def select(table, vals, conditions):
	conditions = clean_conditions(conditions)
	return basic_select(table, vals, conditions)

def clean_conditions(conditions):
	temp_conditions = {}
	for k, v in conditions.items():
		if not isinstance(v, dict):
			temp_conditions[k] = {'compare_to':v, 'condition':'='}
		else:
			temp_conditions[k] = v
	return temp_conditions

print select('test',['election_id','vip_id'],{'election_id':32,'vip_id':1001,'feed_id':{'condition':'not in','compare_to':'random crap'}})
