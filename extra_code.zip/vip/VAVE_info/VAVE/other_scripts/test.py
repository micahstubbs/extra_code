import feedtoflatfiles as ftff
from schemaprops import SchemaProps
import os
import csv

def convert_to_db_files(feed_details, directory, sp):

	for f in os.listdir(directory):
		element_name, extension = f.lower().split(".")
		with open(directory + f, "r") as reader:
			print "reading " + directory + f
			read_data = csv.DictReader(reader)
			with open(directory + element_name + "_db.txt", "w") as writer:
				dict_fields = sp.header("db", element_name)
				type_vals = sp.type_data("db", element_name)
				if "id" in dict_fields:
					dict_fields.pop(dict_fields.index("id"))
					dict_fields.append("feed_id")
				if not "vip_id" in dict_fields:
					dict_fields.append("vip_id")
				if not "election_id" in dict_fields:
					dict_fields.append("election_id")
				out = csv.DictWriter(writer, fieldnames=dict_fields)
				out.writeheader()
				row_count = 0
				processed_count = 0
				for row in read_data:
					if "id" in row:
						row["feed_id"] = row.pop("id")
					row["vip_id"] = feed_details["vip_id"]
					row["election_id"] = feed_details["election_id"]
					out.writerow(row)
					processed_count += 1
		os.remove(directory + f)
		os.rename(directory + element_name + "_db.txt", directory + f)
		print "finished conversion"
	return "something"

sp = SchemaProps()

feed_details = {"election_id":1001, "vip_id":37}

ftff.feed_to_db_files("random/","37-1001.xml",sp.full_header_data("db"),sp.version)

#element_counts = convert_to_db_files(feed_details, "random/", sp)

print element_counts



