#!/usr/bin/env python
# -- coding: utf-8 --

from lxml import etree
from csv import DictReader
from datetime import datetime
from os import path

VERSION = "3.0"
SCHEMA_URL = "https://github.com/votinginfoproject/vip-specification/blob/master/vip_spec_v{0}.xsd".format(VERSION)
HEADER = '<?xml version="1.0" encoding="utf-8"?>\n<vip_object xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="{0}" schemaVersion="{1}">'.format(SCHEMA_URL, VERSION)
FOOTER = "</vip_object>"
ID_FILE = "rotr_data/{0}_rules_of_the_road_verification_expanded_forms_of_voter_id.csv"
RULES_FILE = "rotr_data/{0}_rules_of_the_road_verification_rules_of_the_road_questions.csv"
RULES_PREFIX = 16000
ID_PREFIX = 14000
XML_FILE = "rotr_{0}.xml"
FIPS_FILE = "fips.txt"

fips_data = {}
with open(FIPS_FILE, "r") as r:
	reader = DictReader(r, dialect='excel-tab')
	for row in reader:
		fips_data[row["State"]] = row["FIPS"]

def write_source(state, fips):
	source = etree.Element('source', attrib={'id':'0'})
	name = etree.SubElement(source, "name")
	name.text = state
	vip_id = etree.SubElement(source, "vip_id")
	vip_id.text = fips
	s_datetime = etree.SubElement(source, "datetime")
	s_datetime.text = datetime.isoformat(datetime.now())
	return source

def write_state(state_name, fips):
	state = etree.Element('state', attrib={'id':fips})
	name = etree.SubElement(state, "name")
	name.text = state_name
	return state

def write_election(fips):
	election = etree.Element('election', attrib={'id':'4000'})
	date = etree.SubElement(election, "date")
	date.text = '2012-11-06'
	e_type = etree.SubElement(election, "type")
	e_type.text = 'General'
	state_id = etree.SubElement(election, "state_id")
	state_id.text = fips
	statewide = etree.SubElement(election, "statewide")
	statewide.text = "Yes"
	return election

def write_rules(fips, count, row):
	rules = etree.Element('election_rules', attrib={'id':str(RULES_PREFIX+count), 'verified':row["election_rules_verified"]})
	state_id = etree.SubElement(rules, 'state_id')
	state_id.text = fips
	topic = etree.SubElement(rules, 'topic')
	topic.text = row["election_rules_topic"]
	question = etree.SubElement(rules, 'question')
	question.text = row["election_rules_question"]
	response = etree.SubElement(rules, 'response')
	response.text = row["election_rules_response"]
	citation = etree.SubElement(rules, 'citation')
	section = etree.SubElement(citation, 'section')
	section.text = row["election_rules_citation_section"].decode("utf-8")
	url = etree.SubElement(citation, 'url')
	url.text = row["election_rules_citation_url"]
	return rules

def write_ids(fips, row):
	ids = etree.Element('voter_identification', attrib={'id':str(ID_PREFIX+int(row["voter_identification_id"])), 'verified':row["voter_identification_verified"]})
	state_id = etree.SubElement(ids, 'state_id')
	state_id.text = fips
	name = etree.SubElement(ids, 'name')
	name.text = row["voter_identification_name"]
	id_count = 0
	for key in row.keys():
		if key.startswith("id_requirement") and row[key] == "X":
			temp_elem = etree.Element("id_requirement")
			temp_elem.text = key[len("id_requirement_"):]
			ids.append(temp_elem)
	return ids


for state, fips in fips_data.iteritems():
	if not path.exists(RULES_FILE.format(state.lower())):
		continue
	with open(XML_FILE.format(state), "w") as w:
		w.write(HEADER + "\n")
		w.write(etree.tostring(write_source(state, fips), pretty_print=True))
		w.write(etree.tostring(write_state(state, fips), pretty_print=True))
		w.write(etree.tostring(write_election(fips), pretty_print=True))
		with open(RULES_FILE.format(state.lower()), "r") as r:
			rules = DictReader(r)
			count = 1
			for row in rules:
				w.write(etree.tostring(write_rules(fips, count, row), pretty_print=True))
				count += 1
		with open(ID_FILE.format(state.lower()), "r") as r:
			ids = DictReader(r)
			for row in ids:
				w.write(etree.tostring(write_ids(fips, row), pretty_print=True))
		w.write(FOOTER)
