#!/usr/bin/env python
# -- coding: utf-8 --

from csv import DictReader, DictWriter
from hashlib import md5

def hash_list(data, field_list):
	m = md5()
	for field in field_list:
		m.update("*" + data[field])
	return m.hexdigest()

def clean_sourced(data):
	for k, v in data.iteritems():
		data[k] = ' '.join(v.upper().replace("'","").replace("-"," ").replace("#","").replace("."," ").replace('MT ','MOUNT ').replace('FT ','FORT ').split())
	#	if k == 'precinct_number' and len(data[k]) == 2:
	#		data[k] = data[k].zfill(3)
		if k == 'precinct_name':
			data[k].replace('ONE','1').replace('TWO','2').replace('THREE','3').replace('FOUR','4').replace('FIVE','5').replace('SIX','6').replace('SEVEN','7')
			if data[k].find(' WARD') >= 0:
				print data[k]
				data[k] = data[k][:data[k].find(' WARD')-2]
		temp_list = []
		for val in data[k].split(' '):
			try:
				temp_list.append(str(int(val)))
			except:
				temp_list.append(val.upper())
		data[k] = ' '.join(temp_list)
	print data
	return data

def clean_vf(data):
	for k, v in data.iteritems():
		data[k] = ' '.join(v.upper().replace("'","").replace("-"," ").replace("#","").replace("."," ").replace('MT ','MOUNT ').replace('FT ','FORT ').split()) 
	#	if k == 'precinct_name' or k == 'precinct_number':
	#		data[k] = data[k].split(' ')[0] + str(int(data[k].split(' ')[1]))
		temp_list = []
		for val in data[k].split(' '):
			try:
				temp_list.append(str(int(val)))
			except:
				temp_list.append(val.upper())
		data[k] = ' '.join(temp_list)
	print data
	return data
def get_polls(directory):
	polling_locations = {}

	with open('match_data/{0}/processed_polling_location.csv'.format(directory),'r') as r, open('match_data/{0}/polling_location.txt'.format(directory),'w') as w:
		reader = DictReader(r)
		writer = DictWriter(w, fieldnames=['id','directions','polling_hours','photo_url','address_location_name','address_line1','address_line2','address_city','address_state','address_zip'])
		writer.writeheader()
		for row in reader:
			row.pop('locality_id')
			row.pop('polling_location_locality_count')
			row.pop('source')
			row.pop('INTERNAL_notes')
			row['id'] = row.pop('polling_location_id')
			writer.writerow(row)
			row['polling_location_id'] = row.pop('id')
			polling_locations[row['polling_location_id']] = row
	return polling_locations

def get_precincts(directory, polling_locations):
	precinct_data = {}

	with open('match_data/{0}/processed_precinct.csv'.format(directory),'r') as r:
		reader = DictReader(r)
		for row in reader:
			hash_data = {'county':row['county'],
				#	'city':row['vf_precinct_city'],
					'precinct_name':row['clean_precinct_name'],
					'precinct_number':''}
				#	'precinct_number':row['clean_precinct_number']}
				#	'ward':row['vf_precinct_ward']}
			hash_data = clean_sourced(hash_data)
			#hash_val = hash_list(hash_data,['county', 'city', 'precinct_name', 'precinct_number', 'ward'])
			hash_val = hash_list(hash_data,['county', 'precinct_name','precinct_number'])
		#	row['polling_location_ids'] = row.pop('polling_location_id').decode('utf-8').replace(u'\xb8',",")
			if hash_val in precinct_data:
				print row
				print precinct_data[hash_val]
			precinct_data[hash_val] = {'sourced_precinct_id':row['precinct_id'],
							'sourced_county':row['county'],
							'sourced_city':row['city'],
							'sourced_precinct_name':row['clean_precinct_name'],
							'sourced_precinct_number':row['clean_precinct_number'],
							'sourced_ward':row['ward'],
							'polling_location_ids':row['polling_location_ids'],
							'mail_only':row['mail_only']}
			if row['mail_only'].upper() not in ['Y','YES']:
				precinct_data[hash_val].update(polling_locations[row['polling_location_ids'].split(",")[0]])
	print len(precinct_data)
	return precinct_data

def match_stuff(vf_dir,directory, precinct_data):
	with open(vf_dir,'r') as r, open('match_data/{0}/matches.csv'.format(directory), 'w') as wm, open('match_data/{0}/vf_unmatched.csv'.format(directory), 'w') as vf_um, open('match_data/{0}/source_unmatched.csv'.format(directory), 'w') as s_um:
		reader = DictReader(r)
		match = DictWriter(wm, fieldnames=['sourced_precinct_id','vf_precinct_id','sourced_county','vf_precinct_county','sourced_city','vf_precinct_city','address_city','sourced_precinct_name','vf_precinct_name','sourced_precinct_number','vf_precinct_code','sourced_ward','vf_precinct_ward','vf_precinct_count','mail_only','ballot_style_image_url','polling_location_ids','polling_location_id','address_zip','vf_precinct_zip','directions','polling_hours','photo_url','address_location_name','address_line1','address_line2','address_state','address_1_city','address_1_zip','address_1_house_number','address_1_street_direction','address_1_street_name','address_1_street_suffix','address_1_address_direction','address_2_city','address_2_zip','address_2_house_number','address_2_street_direction','address_2_street_name','address_2_street_suffix','address_2_address_direction','address_3_city','address_3_zip','address_3_house_number','address_3_street_direction','address_3_street_name','address_3_street_suffix','address_3_address_direction','address_4_city','address_4_zip','address_4_house_number','address_4_street_direction','address_4_street_name','address_4_street_suffix','address_4_address_direction','address_5_city','address_5_zip','address_5_house_number','address_5_street_direction','address_5_street_name','address_5_street_suffix','address_5_address_direction'])
		match.writeheader()
		vf_unmatch = DictWriter(vf_um, fieldnames=['vf_precinct_id','vf_precinct_county','vf_precinct_city','vf_precinct_zip','vf_precinct_name','vf_precinct_code','vf_precinct_ward','vf_precinct_count','vf_example_address','address_1_city','address_1_zip','address_1_house_number','address_1_street_direction','address_1_street_name','address_1_street_suffix','address_1_address_direction','address_2_city','address_2_zip','address_2_house_number','address_2_street_direction','address_2_street_name','address_2_street_suffix','address_2_address_direction','address_3_city','address_3_zip','address_3_house_number','address_3_street_direction','address_3_street_name','address_3_street_suffix','address_3_address_direction','address_4_city','address_4_zip','address_4_house_number','address_4_street_direction','address_4_street_name','address_4_street_suffix','address_4_address_direction','address_5_city','address_5_zip','address_5_house_number','address_5_street_direction','address_5_street_name','address_5_street_suffix','address_5_address_direction'])
		vf_unmatch.writeheader()
		sourced_unmatch = DictWriter(s_um, fieldnames=['sourced_precinct_id','sourced_county','sourced_city','sourced_precinct_name','sourced_precinct_number','sourced_ward','mail_only','ballot_style_image_url','polling_location_ids','polling_location_id','directions','polling_hours','photo_url','address_location_name','address_line1','address_line2','address_city','address_state','address_zip'])
		sourced_unmatch.writeheader()
		print "VF Shit"
		for row in reader:
			hash_data = {'county':row['vf_precinct_county'],
			#	'city':row['vf_precinct_city'],
				'precinct_name':row['vf_precinct_name'][-2:],
				'precinct_number':''}
		#		'precinct_number':row['vf_precinct_code']}
			#	'ward':row['vf_precinct_ward']}
			hash_data = clean_vf(hash_data)
			#hash_val = hash_list(hash_data,['county', 'city', 'precinct_name', 'precinct_number', 'ward'])
			hash_val = hash_list(hash_data,['county','precinct_name','precinct_number'])
			if hash_val in precinct_data:
				output = precinct_data.pop(hash_val)
				output.update(row)
				match.writerow(output)
			else:
				vf_unmatch.writerow(row)
		if len(precinct_data) > 0:
			for key,val in precinct_data.iteritems():
				sourced_unmatch.writerow(val)

def main():
	dir_val = 'vip_{0}'
	vf_dir = '/home/jensen/noi/voter_files/vf_ex_precincts/{0}_vf_ex_precincts.txt'
	match_list = ['OKCarter'] 
	for c in match_list:
		print c
		directory = dir_val.format(c.replace(' ','_'))
		vf_directory = vf_dir.format(c.replace(' ','_'))
		polling_locations = get_polls(directory)
		precincts = get_precincts(directory,polling_locations)
		match_stuff(vf_directory,directory,precincts)
	
if __name__ == "__main__":
	main()	
