import csv
import xlrd

data = xlrd.open_workbook('match_data/VIP_CALassen/locality.xls','r')
sh = data.sheet_by_name('Sheet1')
with open('match_data/VIP_CALassen/locality.csv','w') as w:
	writer = csv.writer(w)
	writer.writerow(['id','name','state','type'])
	for rownum in xrange(sh.nrows-1):
		writer.writerow([110000 + int(sh.cell_value(rownum+ 1, 0))] + sh.row_values(rownum+ 1, 1))

data = xlrd.open_workbook('match_data/VIP_CALake/processed_precinct.xls','r')
sh = data.sheet_by_name('Sheet1')
with open('match_data/VIP_CALake/processed_precinct.csv','w') as w:
	writer = csv.writer(w)
	writer.writerow(['locality_id','precinct_locality_count','precinct_id','county','county_fips','city','raw_precinct_name','clean_precinct_name','raw_precinct_number','clean_precinct_number','lowest_political_level','lowest_political_value','ward','mail_only','ballot_style_image_url','polling_location_ids','source','INTERNAL_notes'])
	for rownum in xrange(sh.nrows-1):
		writer.writerow(sh.row_values(rownum+ 1))
