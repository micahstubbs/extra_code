from csv import DictReader, DictWriter

precincts = set([])
with open('match_data/vip_AL/processed_precinct.csv','rb') as r, open('match_data/vip_AL/processed_precinct_fixed.csv','wb') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['city'] = ''
		precinct_val = row['county'] + "*" + row['clean_precinct_name'] + "*" + row['clean_precinct_number'] + '*' + row['ward']
		if precinct_val not in precincts:
			precincts.add(precinct_val)
			writer.writerow(row)	
