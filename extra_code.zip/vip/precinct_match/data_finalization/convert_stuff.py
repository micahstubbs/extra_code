from csv import DictReader, DictWriter

location = {'state':'CA',
		'county':'Santa_Barbara'}
directory = 'vip_{state}{county}/'.format(**location)

with open('{0}locality.csv'.format(directory),'r') as r, open('{0}locality.txt'.format(directory),'w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['id','name','state_id','type'])
	writer.writeheader()
	for row in reader:
		row['id'] = '11' + str(row.pop('locality_id')).zfill(3)
		writer.writerow(row)

poll_prec_ids = set([])
count = 0
with open('{0}matches.csv'.format(directory),'r') as r, open('{0}precinct.txt'.format(directory),'w') as prec_w, open('{0}precinct_polling_location.txt'.format(directory),'w') as precpoll_w:
	#reader = DictReader(r,dialect='excel-tab')
	reader = DictReader(r)
	#reader = DictReader(r,delimiter=';')
	prec_writer = DictWriter(prec_w, fieldnames=['locality_id','name','number','ward','mail_only','ballot_style_image_url','id'])
	precpoll_writer = DictWriter(precpoll_w, fieldnames=['precinct_id','polling_location_id'])
	prec_writer.writeheader()
	precpoll_writer.writeheader()
	for row in reader:
		count += 1
	#	print row
		if row['mail_only'].upper() == 'N':
			row['mail_only'] = 'NO'
		elif row['mail_only'].upper() == 'Y':
			row['mail_only'] = 'YES'
		if str(row['vf_precinct_id']) + "*" + str(row['polling_location_id']) in poll_prec_ids:
			print str(row['vf_precinct_id']) + "*" + str(row['polling_location_id'])
			print count
			continue
		poll_prec_ids.add(str(row['vf_precinct_id']) + "*" + str(row['polling_location_id']))
		prec_writer.writerow({'id':row['vf_precinct_id'],
					'locality_id':'11'+str(row['sourced_precinct_id'][2:5]),
					'name':row['sourced_precinct_name'],
					'number':row['sourced_precinct_number'],
					'ward':row['sourced_ward'],
					'mail_only':row['mail_only'],
					'ballot_style_image_url':row['ballot_style_image_url']})
		if row['mail_only'].upper() == 'YES':
			continue
			print row['mail_only']
		location_ids = row['polling_location_ids'].split(',')
		for loc_id in location_ids:	
			precpoll_writer.writerow({'precinct_id':row['vf_precinct_id'],
							'polling_location_id':loc_id.strip()})

polling_ids = set([])
with open('{0}processed_polling_location.csv'.format(directory),'r') as poll_r, open('{0}polling_location.txt'.format(directory),'w') as poll_w:
	reader = DictReader(poll_r)
	poll_writer = DictWriter(poll_w, fieldnames=['id','directions','polling_hours','photo_url','address_location_name','address_line1','address_city','address_state','address_zip'])
	poll_writer.writeheader()
	for row in reader:
		if row['polling_location_id'] in polling_ids:
			print row['polling_location_id']
			continue
		polling_ids.add(row['polling_location_id'])
		poll_writer.writerow({'id':row['polling_location_id'],
					'directions':row['directions'],
					'polling_hours':row['polling_hours'],
					'photo_url':row['photo_url'],
					'address_location_name':row['address_location_name'],
					'address_line1':row['address_line1'],
					'address_city':row['address_city'],
					'address_state':row['address_state'],
					'address_zip':str(row['address_zip']).zfill(5)})	

with open('../voter_files/vf_deduped/{1}_vf_deduped.txt'.format(directory,location['state'],location['county'].title()),'r') as r, open('{0}street_segment.txt'.format(directory),'w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=['start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_street_direction','non_house_address_street_name','non_house_address_street_suffix','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id','id'])
	writer.writeheader()
	for row in reader:
		if row['county'] != 'SANTA BARBARA':
			continue
		output = {'id':row['vf_id'],
				'precinct_id':row['vf_precinct_id'],
				'start_house_number':row['house_number'],
				'end_house_number':row['house_number'],
				'odd_even_both':'both',
				'start_apartment_number':row['apartment_number'],
				'end_apartment_number':row['apartment_number'],
				'non_house_address_street_direction':row['street_direction'],
				'non_house_address_street_name':row['street_name'],
				'non_house_address_street_suffix':row['street_suffix'],
				'non_house_address_city':row['city'],
				'non_house_address_state':row['state'],
				'non_house_address_zip':row['zip']}
		writer.writerow(output)
