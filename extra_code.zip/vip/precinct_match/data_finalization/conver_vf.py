from csv import DictReader, DictWriter

with open('vip_WY/WY_vf_deduped.txt','r') as r, open('vip_WY/street_segment.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w, fieldnames=['start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_street_direction','non_house_address_street_name','non_house_address_street_suffix','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id','id'])
	writer.writeheader()
	for row in reader:
		output = {'id':row['vf_id'],
				'precinct_id':row['vf_precinct_id'],
				'start_house_number':row['house_number'],
				'end_house_number':row['house_number'],
				'odd_even_both':'both',
				'start_apartment_number':row['apartment_number'],
				'end_apartment_number':row['apartment_number'],
				'non_house_address_street_direction':row['street_direction'],
				'non_house_address_street_name':row['street_name'],
				'non_house_address_street_suffix':row['street_suffix'],
				'non_house_address_city':row['city'],
				'non_house_address_state':row['state'],
				'non_house_address_zip':row['zip']}
		writer.writerow(output)
