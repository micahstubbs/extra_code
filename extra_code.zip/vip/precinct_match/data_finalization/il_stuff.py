import os
import shutil

county_loc = '/home/jensen/Dropbox/Projects/Precinct Matching/Precinct Data/VIP_Texas/{0}/'
finalize_loc = 'vip_TX{0}/' 
loc_file = 'localities/locality.xls'
poll_file = 'processed/processed_polling_location.xls'
matches_file = 'matched_data/matches.csv'
county_list =['EL PASO','FORT BEND']#['COLLIN','DALLAS','EL PASO','FORT BEND','HARRIS','HIDALGO','TARRANT'] 

for c in county_list:
	base_dir = county_loc.format(c.title().replace(' ',' '))
	finalize_dir = finalize_loc.format(c.replace(' ','_'))
	os.mkdir(finalize_dir)
	try:
		shutil.copyfile(base_dir + loc_file,finalize_dir + loc_file.split('/')[1])
	except:
		shutil.copyfile(base_dir + loc_file+'x',finalize_dir + loc_file.split('/')[1]+'x')
	try:
		shutil.copyfile(base_dir + poll_file,finalize_dir + poll_file.split('/')[1])
	except:
		shutil.copyfile(base_dir + poll_file+'x',finalize_dir + poll_file.split('/')[1]+'x')
	try:
		shutil.copyfile(base_dir + matches_file,finalize_dir + matches_file.split('/')[1])
	except:
		shutil.copyfile(base_dir + matches_file+'x',finalize_dir + matches_file.split('/')[1]+'x')
