from csv import DictReader, DictWriter

with open('vip_WY/matches.csv','r') as r, open('vip_WY/precinct.txt','w') as prec_w, open('vip_WY/precinct_polling_location.txt','w') as precpoll_w:
	reader = DictReader(r,delimiter=';')
	prec_writer = DictWriter(prec_w, fieldnames=['locality_id','name','number','ward','mail_only','ballot_style_image_url','id'])
	precpoll_writer = DictWriter(precpoll_w, fieldnames=['precinct_id','polling_location_id'])
	prec_writer.writeheader()
	precpoll_writer.writeheader()
	for row in reader:
		if row['mail_only'].upper() == 'N':
			row['mail_only'] = 'NO'
		elif row['mail_only'].upper() == 'Y':
			row['mail_only'] = 'YES'
		prec_writer.writerow({'id':row['vf_precinct_id'],
					'locality_id':'11'+str(row['sourced_precinct_id'][2:5]),
					'name':row['sourced_precinct_name'],
					'number':row['sourced_precinct_number'],
					'ward':row['sourced_ward'],
					'mail_only':row['mail_only'],
					'ballot_style_image_url':row['ballot_style_image_url']})
		precpoll_writer.writerow({'precinct_id':row['vf_precinct_id'],
						'polling_location_id':row['polling_location_id']})

polling_ids = set([])
with open('vip_WY/processed_polling_location.csv','r') as poll_r, open('vip_WY/polling_location.txt','w') as poll_w:
	reader = DictReader(poll_r)
	poll_writer = DictWriter(poll_w, fieldnames=['id','directions','polling_hours','photo_url','address_location_name','address_line1','address_city','address_state','address_zip'])
	poll_writer.writeheader()
	for row in reader:
		if row['polling_location_id'] in polling_ids:
			continue
		polling_ids.add(row['polling_location_id'])
		poll_writer.writerow({'id':row['polling_location_id'],
					'directions':row['directions'],
					'polling_hours':row['polling_hours'],
					'photo_url':row['photo_url'],
					'address_location_name':row['address_location_name'],
					'address_line1':row['address_line1'],
					'address_city':row['address_city'],
					'address_state':row['address_state'],
					'address_zip':str(row['address_zip']).zfill(5)})				
