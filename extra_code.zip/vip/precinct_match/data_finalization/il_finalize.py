from csv import DictReader, DictWriter
import os
import shutil

county_list =['IROQUOIS'] 

def locality(final_dir, feed_dir):
	with open('{0}locality.csv'.format(final_dir),'r') as r, open('{0}locality.txt'.format(final_dir),'w') as w:
		reader = DictReader(r)
		writer = DictWriter(w,fieldnames=['id','name','state_id','type'])
		writer.writeheader()
		for row in reader:
			row['id'] = '11' + str(row.pop('locality_id')).zfill(3)
			writer.writerow(row)
	shutil.copyfile('{0}locality.txt'.format(final_dir),'{0}locality.txt'.format(feed_dir))

def prec_poll(final_dir, feed_dir):
	poll_prec_ids = set([])
	count = 0
	with open('{0}matches.csv'.format(final_dir),'r') as r, open('{0}precinct.txt'.format(final_dir),'w') as prec_w, open('{0}precinct_polling_location.txt'.format(final_dir),'w') as precpoll_w:
		reader = DictReader(r)
		prec_writer = DictWriter(prec_w, fieldnames=['locality_id','name','number','ward','mail_only','ballot_style_image_url','id'])
		precpoll_writer = DictWriter(precpoll_w, fieldnames=['precinct_id','polling_location_id'])
		prec_writer.writeheader()
		precpoll_writer.writeheader()
		for row in reader:
			count += 1
		#	print row
			if row['mail_only'].upper() == 'N':
				row['mail_only'] = 'NO'
			elif row['mail_only'].upper() == 'Y':
				row['mail_only'] = 'YES'
			if str(row['vf_precinct_id']) + "*" + str(row['polling_location_id']) in poll_prec_ids:
				print str(row['vf_precinct_id']) + "*" + str(row['polling_location_id'])
				print count
				continue
			poll_prec_ids.add(str(row['vf_precinct_id']) + "*" + str(row['polling_location_id']))
			prec_writer.writerow({'id':row['vf_precinct_id'],
						'locality_id':'11'+str(row['sourced_precinct_id'][2:5]),
						'name':row['sourced_precinct_name'],
						'number':row['sourced_precinct_number'],
						'ward':row['sourced_ward'],
						'mail_only':row['mail_only'],
						'ballot_style_image_url':row['ballot_style_image_url']})
			if row['mail_only'].upper() == 'YES':
				continue
				print row['mail_only']
			location_ids = row['polling_location_ids'].split(',')
			for loc_id in location_ids:	
				precpoll_writer.writerow({'precinct_id':row['vf_precinct_id'],
								'polling_location_id':loc_id})
	shutil.copyfile('{0}precinct.txt'.format(final_dir),'{0}precinct.txt'.format(feed_dir))
	shutil.copyfile('{0}precinct_polling_location.txt'.format(final_dir),'{0}precinct_polling_location.txt'.format(feed_dir))

def polling(final_dir, feed_dir):
	polling_ids = set([])
	with open('{0}processed_polling_location.csv'.format(final_dir),'r') as poll_r, open('{0}polling_location.txt'.format(final_dir),'w') as poll_w:
		reader = DictReader(poll_r)
		poll_writer = DictWriter(poll_w, fieldnames=['id','directions','polling_hours','photo_url','address_location_name','address_line1','address_city','address_state','address_zip'])
		poll_writer.writeheader()
		for row in reader:
			if row['polling_location_id'] in polling_ids:
				print row['polling_location_id']
				continue
			polling_ids.add(row['polling_location_id'])
			poll_writer.writerow({'id':row['polling_location_id'],
						'directions':row['directions'],
						'polling_hours':row['polling_hours'],
						'photo_url':row['photo_url'],
						'address_location_name':row['address_location_name'],
						'address_line1':row['address_line1'],
						'address_city':row['address_city'],
						'address_state':row['address_state'],
						'address_zip':str(row['address_zip']).zfill(5)})
	shutil.copyfile('{0}polling_location.txt'.format(final_dir),'{0}polling_location.txt'.format(feed_dir))

def streets(vf_dir, final_dir, feed_dir):
	with open('{0}_vf_deduped.txt'.format(vf_dir),'r') as r, open('{0}street_segment.txt'.format(final_dir),'w') as w:
		reader = DictReader(r)
		writer = DictWriter(w, fieldnames=['start_house_number','end_house_number','odd_even_both','start_apartment_number','end_apartment_number','non_house_address_street_direction','non_house_address_street_name','non_house_address_street_suffix','non_house_address_city','non_house_address_state','non_house_address_zip','precinct_id','id'])
		writer.writeheader()
		for row in reader:
		#	if row['county'] != 'SAN BERNARDINO':
		#		continue
			output = {'id':row['vf_id'],
					'precinct_id':row['vf_precinct_id'],
					'start_house_number':row['house_number'],
					'end_house_number':row['house_number'],
					'odd_even_both':'both',
					'start_apartment_number':row['apartment_number'],
					'end_apartment_number':row['apartment_number'],
					'non_house_address_street_direction':row['street_direction'],
					'non_house_address_street_name':row['street_name'],
					'non_house_address_street_suffix':row['street_suffix'],
					'non_house_address_city':row['city'],
					'non_house_address_state':row['state'],
					'non_house_address_zip':row['zip']}
			writer.writerow(output)
	shutil.copyfile('{0}street_segment.txt'.format(final_dir),'{0}street_segment.txt'.format(feed_dir))

feed_loc = '../../quick_feed/feed_data/vip_IL{0}/'
final_loc = 'vip_IL{0}/'
vf_loc = '../../voter_files/vf_deduped/IL{0}'

for c in county_list:
	print c
	feed_dir = feed_loc.format(c.replace(' ','_').title())
	final_dir = final_loc.format(c.replace(' ','_'))
	vf_dir = vf_loc.format(c.replace(' ','_'))
	os.mkdir(feed_dir)
	shutil.copyfile('vip_IL/election.txt',feed_dir + 'election.txt')
	shutil.copyfile('vip_IL/source.txt',feed_dir + 'source.txt')
	shutil.copyfile('vip_IL/state.txt',feed_dir + 'state.txt')
	locality(final_dir,feed_dir)
	prec_poll(final_dir,feed_dir)
	polling(final_dir,feed_dir)
	streets(vf_dir,final_dir,feed_dir)
