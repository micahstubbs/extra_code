from csv import DictReader, DictWriter

with open('vip_WY/locality.csv','r') as r, open('vip_WY/locality.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=['id','name','state_id','type'])
	writer.writeheader()
	for row in reader:
		row['id'] = '11' + str(row.pop('locality_id'))
		writer.writerow(row)
