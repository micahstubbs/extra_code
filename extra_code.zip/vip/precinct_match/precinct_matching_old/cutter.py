import subprocess
pipe = subprocess.Popen(['cut','-f','1,22,26-29,76-84,86','TS_Google_Geo_WY_20120418.txt'],stdout=subprocess.PIPE)
with open('WY_VF.cut', 'w') as f:
	f.writelines(pipe.stdout)
