from csv import DictReader,DictWriter
from hashlib import md5
from copy import deepcopy

VF_HEADER = ['vf_id', 'house_number', 'zip', 'state', 
		'street_direction', 'street_name', 
		'street_suffix', 'address_direction', 
		'apartment_number', 'county', 'city', 
		'vfp_unsort_id']

VF_HASH_FIELDS = ['vf_reg_cass_street_num', 'vf_reg_cass_city',
			'vf_reg_cass_zip', 'vf_reg_cass_state',
			'vf_reg_cass_pre_directional', 'vf_reg_cass_street_name',
			'vf_reg_cass_street_suffix', 'vf_reg_cass_post_directional',
			'vf_reg_cass_apt_num', 'vf_county_name',
			'vf_precinct_id', 'vf_precinct_name']

VF_CONVERSION = {'house_number':'vf_reg_cass_street_num',
			'zip':'vf_reg_cass_zip',
			'state':'vf_reg_cass_state',
			'street_direction':'vf_reg_cass_pre_directional',
			'street_name':'vf_reg_cass_street_name',
			'street_suffix':'vf_reg_cass_street_suffix',
			'address_direction':'vf_reg_cass_post_directional',
			'apartment_number':'vf_reg_cass_apt_num',
			'county':'vf_county_name',
			'city':'vf_reg_cass_city'}

VFP_UNSORT_HEADER = ['vfp_unsort_id', 'vfp_unsort_county', 'vfp_unsort_city',
			'vfp_unsort_zip', 'vf_precinct_name', 'vf_precinct_code',
			'vfp_id', 'vfp_unsort_count']

VFP_HEADER = ['vfp_id', 'vfp_county', 'vfp_city', 'vfp_zip',
			'vf_precinct_name', 'vf_precinct_code',
			'vfp_count', 'vfp_example_address']

VFP_NOZIP_HASH_FIELDS = ['vf_county_name', 'vf_reg_cass_city',
			'vf_precinct_name', 'vf_precinct_id']

VFP_UNSORT_HASH_FIELDS = ['vf_county_name', 'vf_reg_cass_city',
			'vf_reg_cass_zip', 'vf_precinct_name',
			'vf_precinct_id']

VFP_UNSORT_HASH = ['vfp_unsort_county', 'vfp_unsort_city',
			'vfp_unsort_zip', 'vf_precinct_name',
			'vf_precinct_code']

VFP_HASH_FIELDS = ['vfp_county', 'vfp_city', 'vfp_zip',
			'vf_precinct_name', 'vf_precinct_code']

VFP_NOZIP_CONVERSION = {'vfp_county':'vf_county_name',
			'vfp_city':'vf_reg_cass_city',
			'vf_precinct_name':'vf_precinct_name',
			'vf_precinct_code':'vf_precinct_id'}

FULL_ADDRESS_KEYS = ['vf_reg_cass_street_num', 'vf_reg_cass_pre_directional',
			'vf_reg_cass_street_name', 'vf_reg_cass_street_suffix',
			'vf_reg_cass_post_directional', 'vf_reg_cass_city',
			'vf_reg_cass_zip']

VFP_NOZIP_TO_UNSORT_CONVERSION = {'vfp_unsort_county':'vfp_county',
					'vfp_unsort_city':'vfp_city',
					'vf_precinct_name':'vf_precinct_name',
					'vf_precinct_code':'vf_precinct_code',
					'vfp_id':'vfp_id'}

VOTER_FILE = 'WY_VF.cut'
VF_DEDUPED = 'clean_vf.txt'
FINAL_VF = 'vf.txt'
VFP_DATA = 'vf_precinct.txt'
VFP_UNSORT_DATA = 'vfp_unsort.txt'
VF_PREFIX = 900000000
VFP_PREFIX = 331200000
VFP_UNSORT_PREFIX = 331300000

def get_hash(row, field_list):
	m = md5()
	for field in field_list:
		m.update(row[field])
	return m.hexdigest()

def get_conversion(row, conversion):
	temp_dict = {}
	for key, val in conversion.iteritems():
		temp_dict[key] = row[val]
	return temp_dict

def get_list_hash(hash_list):
	m = md5()
	for val in hash_list:
		m.update(val)
	return m.hexdigest()

with open(VOTER_FILE, "r") as r, open(VF_DEDUPED, "w") as w:
	reader = DictReader(r, dialect='excel-tab')
	writer = DictWriter(w, fieldnames=VF_HEADER)
	writer.writeheader()
	vf_hashes = set()
	precinct_data = {}
	for row in reader:
		vf_hash = get_hash(row, VF_HASH_FIELDS)
		if vf_hash in vf_hashes:
			continue
		vf_hashes.add(vf_hash)
		vfp_unsort_hash = get_hash(row, VFP_UNSORT_HASH_FIELDS)
		vfp_nozip_hash = get_hash(row, VFP_NOZIP_HASH_FIELDS)
		row_zip = row['vf_reg_cass_zip']
		if vfp_nozip_hash not in precinct_data:
			precinct_data[vfp_nozip_hash] = get_conversion(row, VFP_NOZIP_CONVERSION)
			precinct_data[vfp_nozip_hash]['zips'] = {row_zip:1}
			precinct_data[vfp_nozip_hash]['vfp_example_address'] = ' '.join(' '.join([row[key] for key in FULL_ADDRESS_KEYS]).split())
		elif row_zip not in precinct_data[vfp_nozip_hash]['zips']:
			precinct_data[vfp_nozip_hash]['zips'][row_zip] = 1
		else:
			precinct_data[vfp_nozip_hash]['zips'][row_zip] += 1
		vf_output = get_conversion(row, VF_CONVERSION)
		vf_output["vfp_unsort_id"] = vfp_unsort_hash
		vf_output["vf_id"] = str(VF_PREFIX + int(row["voterbase_id"][3:]))
		writer.writerow(vf_output)

del vf_hashes
vfp_unsort_ids = {}

with open(VFP_DATA, "w") as vfp, open(VFP_UNSORT_DATA, "w") as vfp_unsort:
	vfp_writer = DictWriter(vfp, fieldnames=VFP_HEADER)
	vfp_writer.writeheader()
	vfp_count = 1
	vfp_unsort_writer = DictWriter(vfp_unsort, fieldnames=VFP_UNSORT_HEADER)
	vfp_unsort_writer.writeheader()
	vfp_unsort_count = 1
	for key, vfp_dict in precinct_data.iteritems():
		zips = vfp_dict.pop('zips')
		vfp_dict["vfp_id"] = VFP_PREFIX + vfp_count
		max_count = 0
		max_zip = 0
		total_count = 0
		for zip_val, zip_count in zips.iteritems():
			vfp_unsort_dict = get_conversion(vfp_dict, VFP_NOZIP_TO_UNSORT_CONVERSION)
			vfp_unsort_dict.update({'vfp_unsort_zip':zip_val, 'vfp_unsort_id':VFP_UNSORT_PREFIX + vfp_unsort_count, 'vfp_unsort_count':zip_count})
			total_count += zip_count
			vfp_unsort_ids[get_hash(vfp_unsort_dict, VFP_UNSORT_HASH)] = vfp_unsort_dict["vfp_unsort_id"]
			vfp_unsort_writer.writerow(vfp_unsort_dict)
			if zip_count > max_count:
				max_count = zip_count
				max_zip = zip_val
			vfp_unsort_count += 1
		vfp_dict['vfp_zip'] = max_zip
		vfp_dict['vfp_count'] = total_count
		vfp_writer.writerow(vfp_dict)
		vfp_count += 1

with open(FINAL_VF, "w") as vf, open(VF_DEDUPED, "r") as vf_c:
	vf_clean = DictReader(vf_c)
	vf_final = DictWriter(vf, fieldnames=VF_HEADER)
	vf_final.writeheader()
	for row in vf_clean:
		row['vfp_unsort_id'] = vfp_unsort_ids[row['vfp_unsort_id']]
		vf_final.writerow(row)

vfp_data = {}
with open(VFP_DATA, "r") as r:
	reader = csv.DictReader(r)
	for row in reader:
		hash_list = [row["county"].upper(), row["city"].upper(), row["precinct_name"].upper()]
		if hash_list[1].find("(") >= 0:
			hash_list[1] = hash_list[1][:hash_list[1].find("(") - 1]
		if row["precinct_name"].find("(") >= 0:
			hash_list[2] = hash_list[2][:hash_list[2].find("(") - 1] + hash_list[2][hash_list[2].find(")") + 1:]
		hash_val = get_hash_list(hash_list)
		vfp_data[hash_val] = row 
