import psycopg2
from psycopg2 import extras
from hashlib import md5
from csv import DictWriter

connection = psycopg2.connect(host="localhost", database="precinct_match_test", user="jensen", password="password")
cursor = connection.cursor(cursor_factory=extras.RealDictCursor)

sorted_dict = {}
sourced_dict = {}

def get_hash(hash_list):
	m = md5()
	for val in hash_list:
		m.update(val)
	return m.hexdigest()

cursor.execute("SELECT sorted_voterfile_precinct_id, county, city, zip, precinct_name, precinct_code FROM sorted_voterfile_precinct")
data = cursor.fetchall()

for row in data:
	hash_list = [row["county"].strip().upper(), row["city"].strip().upper(), row["precinct_name"].strip().upper()]
	if hash_list[1].find("(") >= 0:
		hash_list[1] = hash_list[1][:hash_list[1].find("(") - 1]
	if row["precinct_name"].find("(") >= 0:
		hash_list[2] = hash_list[2][:hash_list[2].find("(") - 1] + hash_list[2][hash_list[2].find(")") + 1:]
	hash_val = get_hash(hash_list)
	sorted_dict[hash_val] = {'vf_county':row["county"].strip().upper(), 'vf_city':row["city"].strip().upper(), 'vf_precinct_name':row["precinct_name"].strip().upper(), 'vf_precinct_code':row["precinct_code"].strip().upper(), 'sorted_vf_precinct_id':row["sorted_voterfile_precinct_id"], 'zip':row["zip"]}

cursor.execute("SELECT sourced_precinct_id, county, city, precinct_name, precinct_code, ward, mail_only, ballot_style_image_url FROM sourced_precinct")
data = cursor.fetchall()

for row in data:
	hash_list = [row["county"].strip().upper(), row["city"].strip().upper(), row["precinct_name"].strip().upper()]
	if len(hash_list[1]) > 25:
		hash_list[1] = hash_list[2][:25]
	hash_val = get_hash(hash_list)
	sourced_dict[hash_val] = {'sourced_county':row["county"].strip().upper(), 'sourced_city':row["city"].strip().upper(), 'sourced_precinct_name':row["precinct_name"].strip().upper(), 'sourced_precinct_code':row["precinct_code"].strip().upper(), 'sourced_precinct_id':row["sourced_precinct_id"], 'ward':row["ward"], 'mail_only':row["mail_only"], 'ballot_style_image_url':row["ballot_style_image_url"]}

with open('matches.csv', "w") as wm, open('sort_unmatched.csv', "w") as sort_um, open('source_umatched.csv', "w") as source_um:
	match = DictWriter(wm, fieldnames=['vf_county','vf_city','vf_precinct_name','vf_precinct_code','sorted_vf_precinct_id','zip','sourced_county','sourced_city','sourced_precinct_name','sourced_precinct_code','sourced_precinct_id','zip','ward','mail_only','ballot_style_image_url'])
	match.writeheader()
	sort_unmatch = DictWriter(sort_um, fieldnames=['vf_county','vf_city','vf_precinct_name','vf_precinct_code','sorted_vf_precinct_id','zip'])
	sort_unmatch.writeheader()
	sourced_unmatch = DictWriter(source_um, fieldnames=['sourced_county','sourced_city','sourced_precinct_name','sourced_precinct_code','sourced_precinct_id','zip','ward','mail_only','ballot_style_image_url'])
	sourced_unmatch.writeheader()
	for key in sourced_dict:
		if key in sorted_dict:
			write_vals = sorted_dict.pop(key)
			write_vals.update(sourced_dict[key])
			match.writerow(write_vals)
		else:
			sourced_unmatch.writerow(sourced_dict[key])
	if len(sorted_dict) > 0:
		for key in sorted_dict:
			sort_unmatch.writerow(sorted_dict[key])
