import csv
import xlrd
import subprocess
from csv import DictReader,DictWriter
from hashlib import md5
from copy import deepcopy
from townconf import Directories, Files, Prefixes, Headers, HashFields, Conversions, AddressKeys

STATE = 'NH'
STATE_VF = 'TS_Google_Geo_NH_20120604.txt'
BASEDIR = Directories.basedir.format(STATE,'{0}')

def write_csv(state, f_name):
	data = xlrd.open_workbook(Directories.processdir.format(state, f_name)+".xls")
	sh = data.sheet_by_name('Sheet1')
	with open(BASEDIR.format(f_name)+".csv", 'wb') as w:
		writer = csv.writer(w)
		if f_name == 'locality':
			write_locality(sh, writer)
		if f_name == 'processed_polling_location':
			write_processed_polling_location(sh, writer)
		if f_name == 'processed_precinct':
			write_processed_precinct(sh, writer)
	
def write_locality(sh, writer):
	writer.writerow(Headers.locality)
	for row_count in xrange(sh.nrows - 1):
		writer.writerow([110000 + int(sh.cell_value(row_count + 1, 0))] + sh.row_values(row_count + 1, 1))

def write_processed_polling_location(sh, writer):
	writer.writerow(Headers.polling_location)
	for row_count in xrange(sh.nrows - 1):
		writer.writerow([str(c).strip(' ') for c in sh.row_values(row_count + 1, 2, sh.ncols-3)])

def write_processed_precinct(sh, writer):
	writer.writerow(Headers.precinct)
	for row_count in xrange(sh.nrows - 1):
		writer.writerow(sh.row_values(row_count+1, 2, 4) + sh.row_values(row_count+1, 5, 6) + sh.row_values(row_count+1, 7, 8) + sh.row_values(row_count+1, 9, 10) + sh.row_values(row_count+1, 12, 16))

def get_hash(row, field_list):
	m = md5()
	for field in field_list:
		m.update(row[field])
	return m.hexdigest()

def get_hash_list(hash_list):
	m = md5()
	for val in hash_list:
		m.update(val)
	return m.hexdigest()

def get_conversion(row, conversion):
	temp_dict = {}
	for key, val in conversion.iteritems():
		temp_dict[key] = row[val]
	return temp_dict

def cut_vf(state):
	pipe = subprocess.Popen(['cut','-f','1,22,26-29,76-84,86',Directories.vfdir.format(STATE_VF)],stdout=subprocess.PIPE)
	with open(BASEDIR.format(Files.vf_cut.format(state)), 'w') as f:
		f.writelines(pipe.stdout)

def precincts_from_vf(state):
	precinct_data = {}
	with open(BASEDIR.format(Files.vf_cut.format(state))) as r, open(BASEDIR.format(Files.vf_deduped), "w") as w:
		reader = DictReader(r, dialect='excel-tab')
		writer = DictWriter(w, fieldnames=Headers.vf)
		writer.writeheader()
		vf_hashes = set()
		for row in reader:
			vf_hash = get_hash(row, HashFields.vf)
			if vf_hash in vf_hashes:
				continue
			vf_hashes.add(vf_hash)
			vfp_unsort_hash = get_hash(row, HashFields.vfp_unsort)
			vfp_nozip_hash = get_hash(row, HashFields.vfp_nozip)
			row_zip = row['vf_reg_cass_zip']
			if vfp_nozip_hash not in precinct_data:
				precinct_data[vfp_nozip_hash] = get_conversion(row, Conversions.vfp_nozip)
				precinct_data[vfp_nozip_hash]['zips'] = {row_zip:1}
				precinct_data[vfp_nozip_hash]['vfp_example_address'] = ' '.join(' '.join([row[key] for key in AddressKeys.full]).split())
			elif row_zip not in precinct_data[vfp_nozip_hash]['zips']:
				precinct_data[vfp_nozip_hash]['zips'][row_zip] = 1
			else:
				precinct_data[vfp_nozip_hash]['zips'][row_zip] += 1
			vf_output = get_conversion(row, Conversions.vf)
			vf_output["vfp_unsort_id"] = vfp_unsort_hash
			vf_output["vf_id"] = str(Prefixes.vf + int(row["voterbase_id"][3:]))
			writer.writerow(vf_output)
	del vf_hashes
	return precinct_data

def sort_precincts(precinct_data):
	vfp_unsort_ids = {}
	with open(BASEDIR.format(Files.vfp_data), "w") as vfp, open(BASEDIR.format(Files.vfp_unsort), "w") as vfp_unsort:
		vfp_writer = DictWriter(vfp, fieldnames=Headers.vfp)
		vfp_writer.writeheader()
		vfp_count = 1
		vfp_unsort_writer = DictWriter(vfp_unsort, fieldnames=Headers.vfp_unsort)
		vfp_unsort_writer.writeheader()
		vfp_unsort_count = 1
		for key, vfp_dict in precinct_data.iteritems():
			zips = vfp_dict.pop('zips')
			vfp_dict["vfp_id"] = Prefixes.vfp + vfp_count
			max_count = 0
			max_zip = 0
			total_count = 0
			for zip_val, zip_count in zips.iteritems():
				vfp_unsort_dict = get_conversion(vfp_dict, Conversions.vfp_nozip_to_unsort)
				vfp_unsort_dict.update({'vfp_unsort_zip':zip_val, 'vfp_unsort_id':Prefixes.vfp_unsort + vfp_unsort_count, 'vfp_unsort_count':zip_count})
				total_count += zip_count
				vfp_unsort_ids[get_hash(vfp_unsort_dict, HashFields.vfp_unsort_converted)] = vfp_unsort_dict["vfp_unsort_id"]
				vfp_unsort_writer.writerow(vfp_unsort_dict)
				if zip_count > max_count:
					max_count = zip_count
					max_zip = zip_val
				vfp_unsort_count += 1
			vfp_dict['vfp_zip'] = max_zip
			vfp_dict['vfp_count'] = total_count
			vfp_writer.writerow(vfp_dict)
			vfp_count += 1
	return vfp_unsort_ids

def finalize_vf(vfp_unsort_ids):
	with open(BASEDIR.format(Files.vf_final), "w") as vf, open(BASEDIR.format(Files.vf_deduped), "r") as vf_c:
		vf_clean = DictReader(vf_c)
		vf_final = DictWriter(vf, fieldnames=Headers.vf)
		vf_final.writeheader()
		for row in vf_clean:
			row['vfp_unsort_id'] = vfp_unsort_ids[row['vfp_unsort_id']]
			vf_final.writerow(row)

def get_vfp_data():
	vfp_data = {}
	with open(BASEDIR.format(Files.vfp_data), "r") as r:
		reader = DictReader(r)
		for row in reader:
			hash_list = [row["vfp_county"].upper(), row["vfp_city"].upper(), row["vf_precinct_name"].upper()]
			if hash_list[1].find("(") >= 0:
				hash_list[1] = hash_list[1][:hash_list[1].find("(") - 1]
			if row["vf_precinct_name"].find("(") >= 0:
				hash_list[2] = hash_list[2][:hash_list[2].find("(") - 1] + hash_list[2][hash_list[2].find(")") + 1:]
			hash_list[2] = ' '.join(hash_list[2].replace("'", "").replace("-", "").split())
			hash_list[1] = hash_list[1].replace("'","")
			hash_val = get_hash_list(hash_list)
			vfp_data[hash_val] = row
	return vfp_data

def get_polling_data():
	polling_data = {}
	with open(BASEDIR.format('processed_polling_location.csv'), 'r') as r:
		reader = csv.DictReader(r)
		for row in reader:
			polling_data[row['polling_location_id']] = row
	return polling_data

def get_sourced_data():
	sourced_data = {}
	with open(BASEDIR.format('processed_precinct.csv'), 'r') as r:
		reader = csv.DictReader(r)
		for row in reader:
			hash_list = [row['sourced_county'].upper(), row['sourced_city'].upper(), row['sourced_precinct_name'].upper()]
			if len(hash_list[1]) > 25:
				hash_list[1] = hash_list[1][:25]
			hash_list[2] = ' '.join(hash_list[2].replace("'", "").replace("-", "").split())
			hash_list[1] = hash_list[1].replace("'","")
			hash_val = get_hash_list(hash_list)
			sourced_data[hash_val] = row
	return sourced_data

def match_data(vfp_data, polling_data, sourced_data):
	with open(BASEDIR.format(Files.match), 'w') as wm, open(BASEDIR.format(Files.vf_unmatched), 'w') as vf_um, open(BASEDIR.format(Files.sourced_unmatched), 'w') as s_um:
		match = csv.DictWriter(wm, fieldnames=Headers.match)
		match.writeheader()
		vf_unmatch = csv.DictWriter(vf_um, fieldnames=Headers.vf_unmatch)
		vf_unmatch.writeheader()
		sourced_unmatch = csv.DictWriter(s_um, fieldnames=Headers.sourced_unmatch)
		sourced_unmatch.writeheader()

		for key in sourced_data:
			write_vals = sourced_data[key]
			write_vals.update(polling_data[sourced_data[key]["polling_location_ids"]])
			if key in vfp_data:
				write_vals.update(vfp_data.pop(key))
				match.writerow(write_vals)
			else:
				sourced_unmatch.writerow(write_vals)
		if len(vfp_data) > 0:
			for key, val in vfp_data.iteritems():
				vf_unmatch.writerow(val)
for f in Files.process_files:
	write_csv(STATE, f)

#add check if cut_VF file exists, otherwise skip cut and clean
cut_vf(STATE)

precinct_data = precincts_from_vf(STATE)
print len(precinct_data)
vfp_unsort_ids = sort_precincts(precinct_data)
print len(vfp_unsort_ids)
finalize_vf(vfp_unsort_ids)
vfp_data = get_vfp_data()
print len(vfp_data)
polling_data = get_polling_data()
print len(polling_data)
sourced_data = get_sourced_data()
print len(sourced_data)
match_data(vfp_data, polling_data, sourced_data)
