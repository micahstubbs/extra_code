import psycopg2

connection = psycopg2.connect(host='localhost', database='precinct_match_test', user='jensen', password='password')
cursor = connection.cursor()

"CREATE TABLE locality (id SERIAL PRIMARY KEY, locality_id VARCHAR(16), name VARCHAR(128), state_id INTEGER, type VARCHAR(128))"
"CREATE TABLE voterfile (id SERIAL PRIMARY KEY, voterfile_id INTEGER, state VARCHAR(2), county VARCHAR(128), city VARCHAR(128), precinct_voterfile_id INTEGER, precinct_name VARCHAR(128), precinct_code VARCHAR(128), zip INTEGER, street_name VARCHAR(128), street_suffix VARCHAR(128), address_direction VARCHAR(128), street_direction VARCHAR(128), house_number INTEGER, apartment_number VARCHAR(128))"
"CREATE TABLE polling_location (id SERIAL PRIMARY KEY, polling_location_id BIGINT, directions VARCHAR(128), polling_hours VARCHAR(128), photo_url VARCHAR(128), address_location_name VARCHAR(128), address_line1 VARCHAR(128), address_city VARCHAR(128), address_state VARCHAR(2), address_zip INTEGER)"
"CREATE TABLE sourced_precinct (id SERIAL PRIMARY KEY, sourced_precinct_id INTEGER, county VARCHAR(128), city VARCHAR(128), zip INTEGER, precinct_name VARCHAR(128), precinct_code VARCHAR(128), ward VARCHAR(128), mail_only VARCHAR(10), ballot_style_image_url VARCHAR(128), polling_location_ids VARCHAR(128))"
"CREATE TABLE sorted_voterfile_precinct (id SERIAL PRIMARY KEY, sorted_voterfile_precinct_id INTEGER, county VARCHAR(128), city VARCHAR(128), zip INTEGER, precinct_name VARCHAR(128), precinct_code VARCHAR(128), count INTEGER)"
"CREATE TABLE voterfile_precinct (id SERIAL PRIMARY KEY, voterfile_precinct_id INTEGER, county VARCHAR(128), city VARCHAR(128), zip INTEGER, precinct_name VARCHAR(128), precinct_code VARCHAR(128), precinct_match_id INTEGER, count INTEGER)"
