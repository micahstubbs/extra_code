import csv
from hashlib import md5

#if county/town based 
# if county - vf_reg_cass_city:city
# else vf_township: city

FILE = "/home/jensen/Desktop/voter_files/TS_Google_Geo_TN_20120523.txt"
ID_PREFIX = 900000000
VF_HASH_FIELDS = ['vf_reg_cass_street_num',
			'vf_reg_cass_city',
			'vf_reg_cass_zip',
			'vf_reg_cass_state',
			'vf_reg_cass_pre_directional',
			'vf_reg_cass_street_name',
			'vf_reg_cass_street_suffix',
			'vf_reg_cass_post_directional',
			'vf_reg_cass_apt_num',
			'vf_county_name',
			'vf_precinct_id',
			'vf_precinct_name']
VF_CONVERSION_FIELDS = {'voterbase_id':'id',
			'vf_reg_cass_street_num':'house_number',
			'vf_reg_cass_zip':'zip',
			'vf_reg_cass_state':'state',
			'vf_reg_cass_pre_directional':'street_direction',
			'vf_reg_cass_street_name':'street_name',
			'vf_reg_cass_street_suffix':'street_suffix',
			'vf_reg_cass_post_directional':'address_direction',
			'vf_reg_cass_apt_num':'apartment_number',
			'vf_county_name':'county',
			'vf_reg_cass_city':'city',
			'vf_precinct_id':'precinct_code',
			'vf_precinct_name':'precinct_name'}
PRECINCT_HASH_FIELDS = ['vf_county_name',
				'vf_reg_cass_city',
				'vf_precinct_name',
				'vf_precinct_id']

def get_hash(hash_list):
	m = md5()
	for val in hash_list:
		m.update(val)
	return m.hexdigest()

with open(FILE, "r") as r:
	reader = csv.DictReader(r, dialect='excel-tab')
	precinct_data = {}
	for row in reader:
		precinct_hash_vals = []
		for field in PRECINCT_HASH_FIELDS:
			precinct_hash_vals.append(row[field])
		hash_code = get_hash(precinct_hash_vals)
		if hash_code not in precinct_data:
			precinct_data[hash_code] = {'county':row["vf_county_name"],
						'city':row["vf_reg_cass_city"],
						'zips':{row["vf_reg_cass_zip"]:1},
						'precinct_name':row["vf_precinct_name"],
						'precinct_code':row["vf_precinct_id"],
						'example_address':str(row['vf_reg_cass_street_num'] + ' ' + row['vf_reg_cass_pre_directional'] + ' ' + row['vf_reg_cass_street_name'] + ' ' + row['vf_reg_cass_street_suffix'] + ' ' + row['vf_reg_cass_post_directional'] + ' ' + row['vf_reg_cass_city'] + ' ' + row['vf_reg_cass_zip'])}
		elif row["vf_reg_cass_zip"] not in precinct_data[hash_code]['zips']:
			precinct_data[hash_code]['zips'][row["vf_reg_cass_zip"]] = 1
		else:
			precinct_data[hash_code]['zips'][row["vf_reg_cass_zip"]] += 1

match_val = 33120001
vf_val = 33130001
precinct_hashes = {}
PRECINCT_HASH_VALS = ['county','city','zip','precinct_name','precinct_code']
with open("TN_example.txt", "w") as match_w, open("precinct_vf.txt", "w") as vf_w:
	match_writer = csv.DictWriter(match_w, fieldnames=['id','county','city','zip','precinct_name','precinct_code','count','example_address'])
	match_writer.writeheader()
	vf_writer = csv.DictWriter(vf_w, fieldnames=['id','county','city','zip','precinct_name','precinct_code','precinct_match_id','count','example_address'])
	vf_writer.writeheader()
	for key in precinct_data:
		zips = precinct_data[key].pop('zips')
		vf_data = precinct_data[key]
		vf_data['precinct_match_id'] = match_val
		max_count = 0
		max_zip = 0
		total_count = 0
		for zip_val, zip_count in zips.iteritems():
			vf_data['zip'] = zip_val
			vf_data['id'] = vf_val
			vf_data['count'] = zip_count
			total_count += zip_count
			hash_list = []
			for field in PRECINCT_HASH_VALS:
				hash_list.append(vf_data[field])
			hash_code = get_hash(hash_list)
			precinct_hashes[hash_code] = vf_data['precinct_match_id']
			vf_writer.writerow(vf_data)
			vf_val += 1
			if zip_count > max_count:
				max_count = zip_count
				max_zip = zip_val
		vf_data.pop("precinct_match_id")
		match_data = vf_data
		match_data['id'] = match_val
		match_data['zip'] = max_zip
		match_data['count'] = total_count
		match_writer.writerow(match_data)
		match_val += 1	

with open(FILE, "r") as r, open("clean.txt", "w") as w:
	vf_hashes = set()
	reader = csv.DictReader(r, dialect='excel-tab')
	header = VF_CONVERSION_FIELDS.values()
	header.append('precinct_vf_id')
	writer = csv.DictWriter(w, fieldnames=header)
	writer.writeheader()
	for row in reader:
		vf_hash_vals = []
		for field in VF_HASH_FIELDS:
			vf_hash_vals.append(row[field])
		hash_code = get_hash(vf_hash_vals)
		if hash_code not in vf_hashes:
			vf_hashes.add(hash_code)
			output = {}
			precinct_hash_vals = []
			for key, val in VF_CONVERSION_FIELDS.iteritems():
				output[val] = row[key]
			for field in PRECINCT_HASH_VALS:
				precinct_hash_vals.append(output[field])
			hash_code = get_hash(precinct_hash_vals)
			output["precinct_vf_id"] = precinct_hashes[hash_code]
			output["id"] = str(ID_PREFIX + int(output["id"][3:]))
			writer.writerow(output)	
