import psycopg2
import sys

connection = psycopg2.connect(host="localhost", database="precinct_match_test", user="jensen", password="password")
cursor = connection.cursor()

#copy_statement = "COPY locality(locality_id,name,state_id,type) FROM '/tmp/ME/locality.txt' WITH CSV HEADER"

#for f in os.listdir(FEED_DIR + "database_files"):
#	r = csv.DictReader(open(FEED_DIR+"database_files/"+f, "r"))
#	copy_statement = SQL_STATEMENT.format(f.split(".")[0], ",".join(r.fieldnames), f)
copy_statement = "COPY polling_location(polling_location_id,directions,polling_hours,photo_url,address_location_name,address_line1,address_city,address_state,address_zip) FROM '/tmp/ME/polling_location.txt' WITH CSV HEADER"
cursor.copy_expert(copy_statement, sys.stdin)
copy_statement = "COPY sorted_voterfile_precinct(sorted_voterfile_precinct_id,county,city,zip,precinct_name,precinct_code,count) FROM '/tmp/ME/sorted_voterfile_precincts.txt' WITH CSV HEADER"
cursor.copy_expert(copy_statement, sys.stdin)
copy_statement = "COPY sourced_precinct(sourced_precinct_id,county,city,precinct_name,precinct_code,ward,mail_only,ballot_style_image_url,polling_location_ids) FROM '/tmp/ME/sourced_precinct.txt' WITH CSV HEADER"
cursor.copy_expert(copy_statement, sys.stdin)
#copy_statement = "COPY voterfile(house_number,voterfile_id,precinct_code,street_name,street_suffix,county,address_direction,apartment_number,city,street_direction,zip,precinct_name,state,precinct_voterfile_id) FROM '/tmp/ME/voterfile.txt' WITH CSV HEADER"
#cursor.copy_expert(copy_statement, sys.stdin)
#copy_statement = "COPY voterfile_precinct(voterfile_precinct_id,county,city,zip,precinct_name,precinct_code,precinct_match_id,count) FROM '/tmp/ME/voterfile_precincts.txt' WITH CSV HEADER"
#cursor.copy_expert(copy_statement, sys.stdin)
connection.commit()
