class Directories(object):
	basedir = "data/VIP_{0}/match_test/{1}"
	processdir = "data/VIP_{0}/processed/{1}"
	vfdir = "/home/jensen/Desktop/voter_files/{0}"

class Files(object):
	process_files = ['locality', 'processed_polling_location', 'processed_precinct']
	vf_cut = "{0}_VF.cut"
	vf_deduped = "vf_deduped.txt"
	vf_final = "vf.txt"
	vfp_data = "vf_precinct.txt"
	vfp_unsort = "vfp_unsort.txt"
	match = "matches.csv"
	vf_unmatched = "vf_unmatched.csv"
	sourced_unmatched = "sourced_unmatched.csv"

class Prefixes(object):
	vf=900000000
	vfp=331200000
	vfp_unsort=331300000

class Headers(object):
	locality=['locality_id','name','state_id','type']
	polling_location=['polling_location_id','directions',
				'polling_hours','photo_url',
				'address_location_name','address_line1',
				'address_city','address_state','address_zip']
	precinct=['sourced_precinct_id','sourced_county',
			'sourced_city','sourced_precinct_name',
			'sourced_precinct_number','sourced_ward',
			'mail_only','ballot_style_image_url',
			'polling_location_ids']
	vf=['vf_id','house_number','zip',
		'state','street_direction',
		'street_name','street_suffix',
		'address_direction','apartment_number',
		'county','city','vfp_unsort_id']
	vfp=['vfp_id','vfp_county','vfp_city',
		'vfp_zip','vf_precinct_name',
		'vf_precinct_code','vfp_count',
		'vfp_example_address']
	vfp_unsort=['vfp_unsort_id','vfp_unsort_county',
			'vfp_unsort_city','vfp_unsort_zip',
			'vf_precinct_name','vf_precinct_code',
			'vfp_id','vfp_unsort_count',
			'vfp_example_address']
	match=['sourced_precinct_id','vfp_id','sourced_county',
		'vfp_county','sourced_city','vfp_city',
		'address_city','sourced_precinct_name',
		'vf_precinct_name','sourced_precinct_number',
		'vf_precinct_code','sourced_ward','vfp_count',
		'mail_only','ballot_style_image_url',
		'polling_location_ids','polling_location_id',
		'address_zip','vfp_zip','directions','polling_hours',
		'photo_url','address_location_name','address_line1',
		'address_state','vfp_example_address']
	vf_unmatch=['vfp_id','vfp_county','vfp_city',
			'vfp_zip','vf_precinct_name',
			'vf_precinct_code','vfp_count',
			'vfp_example_address']
	sourced_unmatch=['sourced_precinct_id','sourced_county',
				'sourced_city','sourced_precinct_name',
				'sourced_precinct_number','sourced_ward',
				'mail_only','ballot_style_image_url',
				'polling_location_ids','polling_location_id',
				'directions','polling_hours','photo_url',
				'address_location_name','address_line1',
				'address_city','address_state','address_zip']

class HashFields(object):
	vf = ['vf_reg_cass_street_num','vf_reg_cass_city',
		'vf_reg_cass_zip','vf_reg_cass_state',
		'vf_reg_cass_pre_directional','vf_reg_cass_street_name',
		'vf_reg_cass_street_suffix','vf_reg_cass_post_directional',
		'vf_reg_cass_apt_num','vf_county_name','vf_precinct_id',
		'vf_precinct_name']
	vfp_nozip=['vf_county_name','vf_reg_cass_city',
			'vf_precinct_name','vf_precinct_id']
	vfp_unsort=['vf_county_name','vf_reg_cass_city',
			'vf_reg_cass_zip','vf_precinct_name',
			'vf_precinct_id']
	vfp_unsort_whoops=['vfp_unsort_county','vfp_unsort_city',
				'vfp_unsort_zip','vf_precinct_name',
				'vf_precinct_code']
	vfp=['vfp_county','vfp_city','vfp_zip',
		'vf_precinct_name','vf_precinct_code']

class Conversions(object):
	vf = {'house_number':'vf_reg_cass_street_num',
		'zip':'vf_reg_cass_zip',
		'state':'vf_reg_cass_state',
		'street_direction':'vf_reg_cass_pre_directional',
		'street_name':'vf_reg_cass_street_name',
		'street_suffix':'vf_reg_cass_street_suffix',
		'address_direction':'vf_reg_cass_post_directional',
		'apartment_number':'vf_reg_cass_apt_num',
		'county':'vf_county_name',
		'city':'vf_reg_cass_city'}
	vfp_nozip = {'vfp_county':'vf_county_name',
			'vfp_city':'vf_reg_cass_city',
			'vf_precinct_name':'vf_precinct_name',
			'vf_precinct_code':'vf_precinct_id'}
	vfp_nozip_to_unsort = {'vfp_unsort_county':'vfp_county',
				'vfp_unsort_city':'vfp_city',
				'vf_precinct_name':'vf_precinct_name',
				'vf_precinct_code':'vf_precinct_code',
				'vfp_id':'vfp_id',
				'vfp_example_address':'vfp_example_address'}

class AddressKeys(object):
	full = ['vf_reg_cass_street_num','vf_reg_cass_pre_directional',
		'vf_reg_cass_street_name','vf_reg_cass_street_suffix',
		'vf_reg_cass_post_directional','vf_reg_cass_city',
		'vf_reg_cass_zip']
