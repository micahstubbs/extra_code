from csv import DictReader, DictWriter

precincts = {}
new_ids = {}
with open('stored_precincts/TN_vf_ex_precincts.txt','r') as r:
	reader = DictReader(r)
	for row in reader:
		precincts[row['vf_precinct_county']+'*'+row['vf_precinct_name']+'*'+row['vf_precinct_code']] = row['vf_precinct_id']
with open('vf_ex_precincts/TN_vf_ex_precincts.txt','r') as r, open('vf_ex_precincts/TN_vf_ex_precincts_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		if row['vf_precinct_county']+'*'+row['vf_precinct_name']+'*'+row['vf_precinct_code'] not in precincts:
			new_ids[row['vf_precinct_id']] = '99999999'
			row['vf_precinct_id'] = new_ids[row['vf_precinct_id']] 
		else:
			new_ids[row['vf_precinct_id']] = precincts[row['vf_precinct_county']+'*'+row['vf_precinct_name']+'*'+row['vf_precinct_code']]
			row['vf_precinct_id'] = new_ids[row['vf_precinct_id']] 
		writer.writerow(row)
with open('vf_deduped/TN_vf_deduped.txt','r') as r, open('vf_deduped/TN_vf_deduped_fixed.txt','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		row['vf_precinct_id'] = new_ids[row['vf_precinct_id']]
		writer.writerow(row)
