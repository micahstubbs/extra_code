import subprocess
from csv import DictReader
import os

def head_test():
    pipe = subprocess.Popen(['head','-n','1','ND_VF.cut'],stdout=subprocess.PIPE, universal_newlines=True)
    for row in pipe.stdout:
        fields = row.strip().split('\t')

def os_test():
    fields = os.popen('head -n 1 ND_VF.cut').read().strip().split('\t')

def dictreader_test():
    with open('ND_VF.cut') as f:
        f_info = DictReader(f,delimiter='\t')
        fields = f_info.fieldnames

def fopen_test():
    with open('ND_VF.cut') as f:
        fields = next(f).strip().split('\t')

def rstrip_test():
    with open('ND_VF.cut') as f:
        fields = next(f).rstrip().split('\t')

if __name__ == '__main__':
    import timeit
#    print(timeit.timeit('head_test()', setup='from __main__ import head_test', number=10000))
#    print(timeit.timeit('os_test()', setup='from __main__ import os_test', number=10000))
    print(timeit.timeit('dictreader_test()', setup='from __main__ import dictreader_test', number=100000))
    print(timeit.timeit('fopen_test()', setup='from __main__ import fopen_test', number=100000))
    print(timeit.timeit('rstrip_test()', setup='from __main__ import rstrip_test', number=100000))

