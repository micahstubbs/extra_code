from csv import DictReader
bad_shit = set([])
count = 0
with open('TN_VF.cut','r') as r:
	reader = DictReader(r,dialect='excel-tab')
	for row in reader:
		if row['vf_county_name'] == 'SHELBY' and row['vf_precinct_id'][0:3] != row['vf_ward']:
			count += 1
			bad_shit.add(row['vf_ward']+'*'+row['vf_precinct_id'])
print count
print len(bad_shit)
