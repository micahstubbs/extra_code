from csv import DictReader, DictWriter

precincts = {}
with open('stored_precincts/TN_vf_ex_precincts.txt','r') as r:
	reader = DictReader(r)
	for row in reader:
		precincts[row['vf_precinct_id']] = row['vf_precinct_county']+'*'+row['vf_precinct_city']+'*'+row['vf_precinct_zip']+'*'+row['vf_precinct_ward']+'*'+row['vf_precinct_name']+'*'+row['vf_precinct_code']
with open('vf_ex_precincts/TN_vf_ex_precincts.txt','r') as r:
	reader = DictReader(r)
	for row in reader:
		if row['vf_precinct_id'] not in precincts:
			print 'Missing id:' + str(row)
	#	elif precincts[row['vf_precinct_id']] != row['vf_precinct_county']+'*'+row['vf_precinct_city']+'*'+row['vf_precinct_zip']+'*'+row['vf_precinct_ward']+'*'+row['vf_precinct_name']+'*'+row['vf_precinct_code']:
		#	print 'Precinct Mismatch:' + str(row)
