import subprocess
pipe = subprocess.Popen(['cut','-f','1,22,26-29,76-84,86','TS_Google_Geo_110412_TN_20121010.txt'],stdout=subprocess.PIPE)
with open('TN_VF.cut', 'w') as f:
	f.writelines(pipe.stdout)
