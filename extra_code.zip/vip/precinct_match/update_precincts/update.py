from csv import DictReader, DictWriter

prec_polls = {}
polls = {}
columns = ['address_city','polling_location_id','address_zip','directions','polling_hours','photo_url','address_location_name','address_line1','address_state','polling_location_ids']
with open('vip_AR/processed_polling_location.csv','r') as r:
	reader = DictReader(r)
	for row in reader:
		polls[row['polling_location_id']] = {'directions':row['directions'],
							'polling_hours':row['polling_hours'],
							'photo_url':row['photo_url'],
							'address_location_name':row['address_location_name'],
							'address_line1':row['address_line1'],
							'address_city':row['address_city'],
							'address_state':row['address_state'],
							'address_zip':row['address_zip']}
							
with open('vip_AR/processed_precinct.csv','r') as r:
	reader = DictReader(r)
	for row in reader:
		if row['mail_only'].upper() in ['Y','YES']:
			prec_polls[row['precinct_id']] = {'polling_location_ids':'',
								'polling_location_id':'',
								'address_city':'',
								'address_zip':'',
								'directions':'',
								'polling_hours':'',
								'photo_url':'',
								'address_location_name':'',
								'address_line1':'',
								'address_line2':'',
								'address_state':''}
		else:
			polling_id = row['polling_location_ids'].split(',')[0]
			prec_polls[row['precinct_id']] = {'polling_location_ids':row['polling_location_ids'],
								'polling_location_id':polling_id,
								'address_city':polls[polling_id]['address_city'],
								'address_zip':polls[polling_id]['address_zip'],
								'directions':polls[polling_id]['directions'],
								'polling_hours':polls[polling_id]['polling_hours'],
								'photo_url':polls[polling_id]['photo_url'],
								'address_location_name':polls[polling_id]['address_location_name'],
								'address_line1':polls[polling_id]['address_line1'],
								'address_state':polls[polling_id]['address_state']}
with open('vip_AR/matches.csv','r') as r, open('vip_AR/new_matches.csv','w') as w:
	reader = DictReader(r)
	writer = DictWriter(w,fieldnames=reader.fieldnames)
	writer.writeheader()
	for row in reader:
		print row
		for c in columns:
			row[c] = prec_polls[row['sourced_precinct_id']][c]
		writer.writerow(row)
