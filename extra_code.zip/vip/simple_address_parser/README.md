simple_address_parser
=====================

An address parser for well formatted addresses